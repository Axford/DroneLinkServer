/// <reference types="node" />
export type Identifier = string;
export interface MapState { lng: number; lat: number; zoom: number }
export interface UserSummary { _id: Identifier; displayName: string; email: string; profilePicture?: string }
export interface UserRecord extends UserSummary {
  googleId: string; domains: Identifier[]; mapState?: MapState; createdAt?: Date; lastSignInDate?: Date; __v?: number;
}
export interface DomainRecord {
  _id: Identifier; name: string; apiKey?: string; inviteToken?: string;
  users: Array<Identifier | UserSummary>; createdBy?: Identifier | UserSummary | null;
  createdAt?: Date | string; updatedAt?: Date | string; stats?: { nodeCount: number; packetCount: number }; __v?: number;
}
export interface InvitePreviewRecord { _id: Identifier; name: string; createdBy?: UserSummary | null; createdAt?: Date }
export interface PacketRecord {
  _id: Identifier; time: Date; domain: Identifier; packet?: Buffer | null;
  meta?: { id?: number; node?: number; channel?: number; param?: number; msgType?: number }; __v?: number;
}
export interface NewUser { email: string; googleId: string; displayName: string; profilePicture?: string; createdAt?: Date; lastSignInDate?: Date }
export type StorageErrorCode = 'invalid-id' | 'validation' | 'duplicate' | 'unavailable' | 'internal' | 'conflict' | 'forbidden' | 'not-found' | 'archived' | 'invite-unavailable' | 'last-owner';
export class StorageError extends Error {
  constructor(code: StorageErrorCode, details?: { field?: string; issues?: Array<{ field: string; message: string }> });
  code: StorageErrorCode; field?: string; issues?: Array<{ field: string; message: string }>;
}
export type DomainRole = 'owner' | 'editor' | 'viewer';
export interface ActorRequirement { userId: Identifier; sessionEpoch: number; allowedRoles: DomainRole[]; allowPlatformAdmin: boolean }
export interface VerifiedIdentity extends NewUser { emailVerified: true }
export interface AccessUser extends UserRecord { emailCanonical: string; emailVerified: boolean; stagingAccess?: boolean }
export interface AccessControl { schemaVersion: 1; revision: number; planDigest: string; state: 'maintenance' | 'ready'; sessionEpoch: number; soleAdmin?: { userId: string; googleId: string; grantedAt: Date } }
export interface AccessDomain extends DomainRecord { users: Identifier[]; createdBy: Identifier; members: Record<Identifier, DomainRole>; status: 'active' | 'archived'; revision: number; invitationEpoch: number; archivedAt: Date | null; archivedBy: Identifier | null; createdAt: Date; updatedAt: Date; apiKey: string }
export interface AccessContext { control: AccessControl; user: AccessUser | null; domain: AccessDomain | null; role: DomainRole | null }
export interface PageOptions { cursor?: string; limit?: number }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface DomainMutation { domainId: Identifier; revision: number }
export interface InvitationProof { invitationId: Identifier; tokenHash: string }
export interface Invitation { _id: Identifier; domainId: Identifier; emailCanonical: string; role: DomainRole; invitationEpoch: number; revision: number; createdBy: Identifier; issuedAt: Date; expiresAt: Date; state: 'pending' | 'accepted' | 'revoked' | 'superseded'; effectiveState: 'pending' | 'accepted' | 'revoked' | 'superseded' | 'expired'; acceptedBy?: Identifier; acceptedAt?: Date }
export interface MigrationPlan { version: 1; projectId: string; databaseId: string; schemaVersion: 1; controlRevision: number | null; sessionEpoch: number; digest: string; domains: Array<{ domainId: string; createdBy: string | null; users: string[]; members: Record<string, DomainRole>; sourceDigest: string; revision: number; retiredInvite: boolean }>; users: Array<{ userId: string; googleId: string | null; emailVerified: boolean; emailCanonical: string | null; sourceDigest: string }>; blockers: Array<{ kind: string; domainId?: string; userId?: string; userIds?: string[] }>; unresolvedOwners: string[] }
export interface AccessCheck { indexes: { mode: 'emulator' | 'managed'; ready: boolean; managedVerified: boolean }; schemaVersion: number; state: string; revision: number; planDigest: string; issues: Array<{ kind: string; domainId?: string; userId?: string }> }
export interface PacketPageOptions { domainId: Identifier; from?: Date; until?: Date; cursor?: string; limit?: number }
export interface NewPacket { domain: Identifier; time: Date; packet: Buffer; meta?: PacketRecord['meta'] }
export interface PacketPage { items: PacketRecord[]; nextCursor: string | null; cursor: string; from: Date; until?: Date }
export interface SessionRecord { data: Record<string, unknown>; createdAt: Date; expiresAt: Date }
export interface FirestoreStore {
  access: { getControl(): Promise<AccessControl | null> };
  users: {
    getById(id: Identifier): Promise<AccessUser | null>;
    findByGoogleId(id: string): Promise<AccessUser | null>;
    registerVerifiedSignIn(data: VerifiedIdentity, time?: Date): Promise<AccessUser>;
    updateMapState(id: Identifier, state: MapState): Promise<AccessUser>;
  };
  domains: {
    getById(id: Identifier): Promise<AccessDomain | null>;
    getAccessContext(domainId: Identifier, userId: Identifier): Promise<AccessContext>;
    listForActor(actor: ActorRequirement, options?: PageOptions & { status?: 'active' | 'archived' }): Promise<Page<AccessDomain>>;
    createOwned(actor: ActorRequirement, input: { name: string }): Promise<AccessDomain>;
    renameAuthorized(actor: ActorRequirement, input: DomainMutation & { name: string }): Promise<AccessDomain>;
    listMembers(actor: ActorRequirement, input: PageOptions & { domainId: Identifier }): Promise<Page<UserSummary & { role: DomainRole }>>;
    changeMember(actor: ActorRequirement, input: DomainMutation & { userId: Identifier; role: DomainRole | null }): Promise<AccessDomain>;
    leave(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    archive(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    restore(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    rotateKey(actor: ActorRequirement, input: DomainMutation & { newKey: string }): Promise<AccessDomain>;
  };
  invitations: {
    issue(actor: ActorRequirement, input: { domainId: Identifier; emailCanonical: string; role: DomainRole; tokenHash: string }): Promise<Invitation>;
    reissue(actor: ActorRequirement, input: DomainMutation & { invitationId: Identifier; role: DomainRole; tokenHash: string }): Promise<Invitation>;
    revoke(actor: ActorRequirement, input: DomainMutation & { invitationId: Identifier }): Promise<Invitation>;
    list(actor: ActorRequirement, input: PageOptions & { domainId: Identifier }): Promise<Page<Invitation>>;
    inspect(proof: InvitationProof, actor: ActorRequirement): Promise<{ domainName: string; role: DomainRole; inviterDisplayName: string; expiresAt: Date }>;
    accept(actor: ActorRequirement, proof: InvitationProof): Promise<{ domainId: Identifier; role: DomainRole }>;
  };
  sessions: {
    get(id: string, now?: Date): Promise<SessionRecord | null>;
    put(id: string, value: SessionRecord): Promise<void>;
    remove(id: string): Promise<void>;
  };
  packets: {
    enqueue(data: NewPacket): Promise<{ accepted: true; packetId: string }>;
    readPage(options: PacketPageOptions): Promise<PacketPage>;
    waitForPage(options: PacketPageOptions & { timeoutMs?: number; signal?: AbortSignal }): Promise<PacketPage>;
    countRetained(domainId: Identifier): Promise<number>;
  };
  close(): Promise<void>;
}
export interface FirestoreOptions {
  projectId: string; databaseId?: string; emulatorHost?: string;
  flushIntervalMs?: number; maxChunkPackets?: number; maxChunkBytes?: number; maxBufferBytes?: number;
  writeTimeoutMs?: number; onPacketDrop?: (event: { domainId: string; packetCount: number; category: string }) => void;
}
export function openFirestoreStore(options: FirestoreOptions): Promise<FirestoreStore>;

export type Store = FirestoreStore;
