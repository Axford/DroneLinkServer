'use strict';
const { StorageError } = require('./lib/errors');
// Loading the package opens no database, listener or timer.
module.exports = {
    StorageError,
    openFirestoreStore: (...args) => require('./lib/firestore').openFirestoreStore(...args)
};
