import { FirestoreOptions, AccessControl, AccessCheck, DomainRole, MigrationPlan } from './index';
export interface AccessOperatorStore {
  previewMigration(input: { schemaVersion: 1 }): Promise<MigrationPlan>;
  beginMigration(input: { expectedSchemaVersion: 0; planDigest: string; reviewedPlan?: MigrationPlan }): Promise<{ state: string; revision: number }>;
  reviseMigration(input: { reviewedPlan: MigrationPlan; expectedControlRevision: number }): Promise<{ state: string; revision: number }>;
  applyUserMigration(input: { userId: string; sourceRevision: string; planDigest: string }): Promise<void>;
  applyDomainMigration(input: { domainId: string; sourceRevision: string; proposedRoles: Record<string, DomainRole>; planDigest: string }): Promise<void>;
  grantSoleAdmin(input: { userId: string; googleId: string; expectedControlRevision: number }): Promise<AccessControl>;
  recoverSoleAdmin(input: { oldGoogleId: string; newUserId: string; newGoogleId: string; expectedControlRevision: number; reason: string }): Promise<AccessControl>;
  repairMembers(input: { domainId: string; expectedRevision: number; changes: Array<{ userId: string; role: DomainRole | null }>; reason: string; allowNoOwner?: boolean; apply?: boolean }): Promise<{ domainId: string; affectedIds: string[]; remainingOwners: number; revision: number; applied: boolean }>;
  checkMigration(input: { planDigest: string }): Promise<AccessCheck>;
  activate(input: { planDigest: string; expectedControlRevision: number }): Promise<{ state: 'ready'; revision: number }>;
  close(): Promise<void>;
}
export function openAccessOperatorStore(options: FirestoreOptions & { databaseId: string }): Promise<AccessOperatorStore>;
