/// <reference types="node" />
export type Identifier = string;
export interface MapState { lng: number; lat: number; zoom: number }
export interface UserSummary { _id: Identifier; displayName: string; email: string; profilePicture?: string }
export interface UserRecord extends UserSummary {
  googleId: string; domains: Identifier[]; mapState?: MapState; createdAt?: Date; lastSignInDate?: Date; __v?: number;
}
export interface DomainRecord {
  _id: Identifier; name: string; apiKey?: string; inviteToken?: string;
  users: Array<Identifier | UserSummary>; createdBy?: Identifier | UserSummary | null;
  createdAt?: Date | string; updatedAt?: Date | string; stats?: { nodeCount: number; packetCount: number }; __v?: number;
}
export interface InvitePreviewRecord { _id: Identifier; name: string; createdBy?: UserSummary | null; createdAt?: Date }
export interface PacketRecord {
  _id: Identifier; time: Date; domain: Identifier; packet?: Buffer | null;
  meta?: { id?: number; node?: number; channel?: number; param?: number; msgType?: number }; __v?: number;
}
export interface NewUser { email: string; googleId: string; displayName: string; profilePicture?: string; createdAt?: Date; lastSignInDate?: Date }
export type StorageErrorCode = 'invalid-id' | 'validation' | 'duplicate' | 'unavailable' | 'internal' | 'conflict';
export class StorageError extends Error {
  constructor(code: StorageErrorCode, details?: { field?: string; issues?: Array<{ field: string; message: string }> });
  code: StorageErrorCode; field?: string; issues?: Array<{ field: string; message: string }>;
}
/** Native Firestore interface introduced by SEP-06. SDK objects never cross it. */
export interface FirestoreUser extends UserRecord { stagingAccess: boolean }
export interface VersionedDomain extends DomainRecord { revision: number; createdAt: Date; updatedAt: Date; apiKey: string; inviteToken: string }
export interface DomainPage { items: VersionedDomain[]; nextCursor: string | null }
export interface PacketPageOptions { domainId: Identifier; from?: Date; until?: Date; cursor?: string; limit?: number }
export interface NewPacket { domain: Identifier; time: Date; packet: Buffer; meta?: PacketRecord['meta'] }
export interface PacketPage { items: PacketRecord[]; nextCursor: string | null; cursor: string; from: Date; until?: Date }
export interface SessionRecord { data: Record<string, unknown>; createdAt: Date; expiresAt: Date }
export interface FirestoreStore {
  users: {
    getById(id: Identifier): Promise<FirestoreUser | null>;
    findByGoogleId(id: string): Promise<FirestoreUser | null>;
    registerSignIn(data: NewUser, time?: Date): Promise<FirestoreUser>;
    updateMapState(id: Identifier, state: MapState): Promise<FirestoreUser>;
  };
  domains: {
    getById(id: Identifier): Promise<VersionedDomain | null>;
    getDetails(id: Identifier): Promise<VersionedDomain | null>;
    findByInviteToken(token: string, preview?: boolean): Promise<VersionedDomain | InvitePreviewRecord | null>;
    findNamedForUser(name: string, userId: Identifier, excludeId?: Identifier): Promise<VersionedDomain | null>;
    listForUser(userId: Identifier, options?: { cursor?: string; limit?: number }): Promise<DomainPage>;
    createWithCreator(data: { name: string; createdBy: Identifier; apiKey?: string; inviteToken?: string }): Promise<VersionedDomain>;
    addMemberAndLink(id: Identifier, userId: Identifier, precondition: { inviteToken: string }): Promise<VersionedDomain>;
    deleteWithUserLinks(id: Identifier, revision: number): Promise<void>;
    rename(id: Identifier, name: string, revision: number): Promise<VersionedDomain>;
    setApiKey(id: Identifier, value: string, revision: number): Promise<VersionedDomain>;
    setInviteToken(id: Identifier, value: string, revision: number): Promise<VersionedDomain>;
  };
  sessions: {
    get(id: string, now?: Date): Promise<SessionRecord | null>;
    put(id: string, value: SessionRecord): Promise<void>;
    remove(id: string): Promise<void>;
  };
  packets: {
    enqueue(data: NewPacket): Promise<{ accepted: true; packetId: string }>;
    readPage(options: PacketPageOptions): Promise<PacketPage>;
    waitForPage(options: PacketPageOptions & { timeoutMs?: number; signal?: AbortSignal }): Promise<PacketPage>;
    countRetained(domainId: Identifier): Promise<number>;
  };
  close(): Promise<void>;
}
export interface FirestoreOptions {
  projectId: string; databaseId?: string; emulatorHost?: string;
  flushIntervalMs?: number; maxChunkPackets?: number; maxChunkBytes?: number; maxBufferBytes?: number;
  writeTimeoutMs?: number; onPacketDrop?: (event: { domainId: string; packetCount: number; category: string }) => void;
}
export function openFirestoreStore(options: FirestoreOptions): Promise<FirestoreStore>;

export type Store = FirestoreStore;
