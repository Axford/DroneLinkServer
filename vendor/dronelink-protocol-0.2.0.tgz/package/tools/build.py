#!/usr/bin/env python3
"""Build constants from frozen firmware headers; never modify firmware or siblings."""
import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def firmware_definitions():
    provenance = json.loads((ROOT / 'firmware/provenance.json').read_text())
    headers = {}
    for source, item in provenance['files'].items():
        raw = (ROOT / item['snapshot']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item['sha256'], f'{source}: snapshot checksum mismatch'
        headers[source] = raw.decode()
    constants = {}
    prefixes = ('DRONE_LINK_MSG_TYPE_', 'DRONE_LINK_MSG_PRIORITY_')
    named = {'DRONE_LINK_SOURCE_OWNER', 'DRONE_LINK_CHANNEL_ALL', 'DRONE_LINK_PARAM_ALL',
             'DRONE_LINK_MSG_MAX_PAYLOAD', 'DRONE_LINK_MSG_WRITABLE',
             'DRONE_MODULE_PARAM_STATUS', 'DRONE_MODULE_PARAM_NAME', 'DRONE_MODULE_PARAM_ERROR',
             'DRONE_MODULE_PARAM_RESETCOUNT', 'DRONE_MODULE_PARAM_TYPE'}
    for text in headers.values():
        for name, token in re.findall(r'^#define\s+(\w+)\s+(0b[01]+|0x[\da-fA-F]+|\d+)\b', text, re.M):
            if name in named or name.startswith(prefixes):
                constants[name] = int(token, 0) if token.startswith(('0x', '0b')) else int(token)
    assert named <= constants.keys(), 'Missing expected firmware definitions'
    for prefix in prefixes:
        assert sum(key.startswith(prefix) for key in constants) == (8 if 'TYPE_' in prefix else 4)
    match = re.search(r'DRONE_LINK_MSG_TYPE_SIZES\[16\]\s*=\s*\{([^}]+)\}', headers['src/DroneLinkMsg.h'])
    assert match, 'Firmware size table shape changed; review required'
    sizes = [int(x.strip()) for x in match[1].split(',')]
    assert len(sizes) == 16
    # Layout facts are checked against the real packed structs by the host C++ test.
    constants['DRONE_LINK_MSG_HEADER_BYTES'] = 5
    return provenance, constants, sizes


def outputs():
    provenance, constants, sizes = firmware_definitions()
    version = json.loads((ROOT / 'package.json').read_text())['version']
    banner = f'// Generated from pinned DroneNode headers; package {version}. Do not edit.\n'
    js = banner + ''.join(f'export const {k} = {v};\n' for k, v in constants.items())
    js += f'export const DRONE_LINK_MSG_TYPE_SIZES = {json.dumps(sizes)};\n'
    dts = banner + ''.join(f'export declare const {k}: {v};\n' for k, v in constants.items())
    dts += 'export declare const DRONE_LINK_MSG_TYPE_SIZES: number[];\n'
    dts += 'export type DroneLinkMessageType = ' + ' | '.join(str(constants['DRONE_LINK_MSG_TYPE_' + n]) for n in ('UINT8_T','ADDR','UINT32_T','FLOAT','CHAR','NAME','NAMEQUERY','QUERY')) + ';\n'
    dts += 'export type DroneLinkPriority = 0 | 1 | 2 | 3;\n'
    dts += 'export interface DroneLinkPayloadAddress { source: number; node: number; channel: number; param: number; priority: DroneLinkPriority; }\n'
    js += (ROOT / 'src/validation.mjs').read_text()
    dts += (ROOT / 'src/validation.d.ts').read_text()
    cpp = banner + '#pragma once\nnamespace dronelink_reference {\n'
    cpp += ''.join(f'constexpr unsigned reference_{k} = {v};\n' for k,v in constants.items())
    cpp += 'constexpr unsigned reference_type_sizes[16] = {' + ', '.join(map(str,sizes)) + '};\n}\n'
    return {'index.mjs':js, 'index.d.ts':dts, 'protocol.h':cpp,
            'provenance.json':json.dumps(provenance,indent=2)+'\n'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--firmware', type=Path, help='Explicit firmware checkout to compare, read-only; not needed by consumers')
    args = parser.parse_args()
    if args.firmware:
        provenance, _, _ = firmware_definitions()
        for source, item in provenance['files'].items():
            actual = (args.firmware / source).read_bytes()
            assert hashlib.sha256(actual).hexdigest() == item['sha256'], f'{source}: checkout differs from pinned snapshot; review conflict'
    for name, content in outputs().items():
        path = ROOT / 'dist' / name
        if args.check:
            assert path.exists() and path.read_text() == content, f'Stale generated artifact: {path}'
        else:
            path.parent.mkdir(exist_ok=True)
            path.write_text(content)
    print('PASS: pinned firmware checksums and deterministic protocol artifacts' + ('; live header comparison' if args.firmware else ''))


if __name__ == '__main__':
    main()
