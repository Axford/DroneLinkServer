'use strict';
// Separate privileged composition; importing either entry point starts no resources.
module.exports = { openAccessOperatorStore: options => require('./lib/firestore').openAccessOperatorStore(options) };
