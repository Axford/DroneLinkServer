// Optional Node-only compatibility harness. Production entrypoints never import this module.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

export const vectors = JSON.parse(readFileSync(new URL('../fixtures.json', import.meta.url))).vectors;
const bytes = vector => Uint8Array.from(vector.decoded.payload);
export const rawBytes = vector => Uint8Array.from(Buffer.from(vector.hex.replaceAll(' ', ''), 'hex'));

export function encodeVector(Codec, vector) {
  const msg = new Codec();
  const d = vector.decoded;
  switch (d.msgType) {
    case 0: msg.setUint8(d.values); break;
    case 1: msg.setAddr(d.payload); break;
    case 2: msg.setUint32(d.values); break;
    case 3: msg.setFloat(d.values); break;
    case 4:
    case 5:
      // Use the raw single-byte string, including bytes after NUL, when encoding.
      msg.setString(String.fromCharCode(...d.payload));
      msg.msgType = d.msgType;
      break;
    default: throw new Error('Fixture outside supported subset');
  }
  for (const name of ['source','node','channel','param','priority','writable']) msg[name] = d[name];
  return msg;
}

export function assertDecoded(msg, vector) {
  const d = vector.decoded;
  for (const name of ['source','node','channel','param','priority','msgType','writable']) {
    assert.equal(msg[name], d[name], `${vector.name}: ${name}`);
  }
  assert.equal(msg.msgLength, d.payload.length, vector.name);
  assert.equal(msg.totalSize(), d.payload.length + 5, vector.name);
  assert.deepEqual(msg.encodeUnframed(), rawBytes(vector), vector.name);
  if (d.msgType === 4 || d.msgType === 5) assert.equal(msg.payloadToString(), d.values[0], vector.name);
  else assert.deepEqual(Array.from(msg.valueArray()), d.msgType === 1 ? Array.from(bytes(vector)) : d.values, vector.name);
}

export function registerCodecTests(Codec, label) {
  for (const vector of vectors) {
    test(`${label}: ${vector.name}: decode, encode and round trip`, () => {
      assertDecoded(new Codec(rawBytes(vector).buffer), vector);
      const encoded = encodeVector(Codec, vector).encodeUnframed();
      assert.deepEqual(encoded, rawBytes(vector), vector.name);
      assertDecoded(new Codec(encoded.buffer), vector);
    });
  }
  test(`${label}: every priority and writable combination preserves all parameter bits`, () => {
    for (let priority = 0; priority < 4; priority++) for (const writable of [false,true]) {
      const msg = new Codec();
      msg.setUint8([255]);
      Object.assign(msg, {source:255,node:255,channel:255,param:63,priority,writable});
      const expected = Uint8Array.from([255,255,255,(priority << 6)|63,writable ? 128 : 0,255]);
      assert.deepEqual(msg.encodeUnframed(), expected);
      const decoded = new Codec(expected.buffer);
      assert.equal(decoded.priority, priority);
      assert.equal(decoded.writable, writable);
      assert.equal(decoded.param, 63);
    }
  });
  test(`${label}: characterization only: truncated payload zero-fills; trailing bytes ignored`, () => {
    assert.deepEqual(new Codec(Uint8Array.from([0,1,1,1,3,42]).buffer).valueArray(), [42,0,0,0]);
    assert.deepEqual(new Codec(Uint8Array.from([0,1,1,1,0,42,99]).buffer).valueArray(), [42]);
    const shortHeader = new Codec(Uint8Array.from([0,1]).buffer);
    assert.equal(shortHeader.msgLength, 1);
    assert.deepEqual(shortHeader.valueArray(), [0]);
  });
  test(`${label}: characterization only: misaligned uint32 length is retained; value view ignores partial element`, () => {
    const msg = new Codec(Uint8Array.from([0,1,1,1,0x22,1,2,3]).buffer);
    assert.equal(msg.msgLength, 3);
    assert.deepEqual(Array.from(msg.valueArray()), []);
    assert.deepEqual(msg.encodeUnframed(), Uint8Array.from([0,1,1,1,0x22,1,2,3]));
  });
  test(`${label}: ADDR helpers preserve one through four complete entries`, () => {
    const all = [0,2,3,0xc4, 0,5,6,0x87, 255,254,253,0x7f, 1,2,3,4];
    for (const length of [4,8,12,16]) {
      const values = all.slice(0,length);
      const msg = new Codec(); msg.setAddr(values);
      assert.equal(msg.msgLength,length);
      assert.deepEqual(Array.from(msg.valueArray()),values);
      const expected = Uint8Array.from([0,0,0,0,0x10 | (length-1),...values]);
      assert.deepEqual(msg.encodeUnframed(),expected);
      assert.deepEqual(Array.from(new Codec(expected.buffer).valueArray()),values);
    }
  });
  test(`${label}: invalid ADDR setters reject without replacing the current message`, () => {
    const msg = new Codec(); msg.setUint8([42]);
    const before = msg.encodeUnframed();
    for (const values of [[],[0],[0,1,2],Array(5).fill(0),Array(20).fill(0),[0,1,2,-1],[0,1,2,256],[0,1,2,1.5],[0,1,2,NaN],[0,1,2,Infinity]]) {
      assert.throws(() => msg.setAddr(values),RangeError);
      assert.deepEqual(msg.encodeUnframed(),before);
    }
  });
  test(`${label}: legacy link frames include the full payload and header/payload CRC`, () => {
    const cases = [
      { type: 0, payload: [42], hex: 'fe00070488802a4b' },
      { type: 0, payload: Array.from({length:16},(_,i)=>i), hex: 'fe000704888f000102030405060708090a0b0c0d0e0fa7' },
      { type: 6, payload: [0], hex: 'fe00070488e00068' },
      { type: 7, payload: [0], hex: 'fe00070488f0003f' }
    ];
    for (const row of cases) {
      const msg = new Codec(); msg.setUint8(row.payload);
      Object.assign(msg,{source:0,node:7,channel:4,param:8,priority:2,writable:true,msgType:row.type});
      const frame = msg.encode();
      assert.equal(Buffer.from(frame).toString('hex'),row.hex);
      assert.deepEqual(frame.subarray(1,-1),msg.encodeUnframed());
    }
  });
  test(`${label}: framed encoding refuses unrepresentable lengths including empty queries`, () => {
    const msg = new Codec(); msg.setUint8([42]);
    for (const length of [0,17,-1,1.5,NaN,Infinity]) {
      msg.msgLength = length;
      assert.throws(() => msg.encode(),RangeError);
    }
  });
  test(`${label}: log timestamps decode as unsigned low32 bits with unchanged big-endian bytes`, () => {
    for (const [input,expected,bytes] of [
      [0,0,[0,0,0,0]], [0x7fffffff,0x7fffffff,[127,255,255,255]],
      [0x80000000,0x80000000,[128,0,0,0]], [0xffffffff,0xffffffff,[255,255,255,255]],
      [0x100000005,5,[0,0,0,5]]
    ]) {
      const msg = new Codec(); msg.setUint8([42]); msg.timestamp=input;
      const log=msg.encodeForLog();
      assert.deepEqual(Array.from(log),[11,...bytes,0,0,0,0,0,42]);
      const decoded = new Codec(); decoded.parseFromLog(log);
      assert.equal(decoded.timestamp,expected);
      assert.deepEqual(decoded.encodeForLog(),log);
      assert.deepEqual(decoded.encodeUnframed(),msg.encodeUnframed());
    }
  });
}
