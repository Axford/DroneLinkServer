/// <reference types="node" />
export type Identifier = string;
export interface MapState { lng: number; lat: number; zoom: number }
export interface UserSummary { _id: Identifier; displayName: string; email: string; profilePicture?: string }
export interface UserRecord extends UserSummary {
  googleId?: string; domains: Identifier[]; mapState?: MapState; createdAt?: Date; lastSignInDate?: Date; __v?: number;
}
export interface DomainRecord {
  _id: Identifier; name: string; apiKey?: string; inviteToken?: string;
  users: Array<Identifier | UserSummary>; createdBy?: Identifier | UserSummary | null;
  createdAt?: Date | string; updatedAt?: Date | string; stats?: { nodeCount: number; packetCount: number }; __v?: number;
}
export interface InvitePreviewRecord { _id: Identifier; name: string; createdBy?: UserSummary | null; createdAt?: Date }
export interface PacketRecord {
  _id: Identifier; time: Date; domain: Identifier; packet?: Buffer | null;
  meta?: { id?: number; node?: number; channel?: number; param?: number; msgType?: number; source?: number };
  origin?: { kind: 'http' | 'gateway'; gatewayId?: string }; __v?: number;
}
export interface NewUser { email: string; googleId: string; displayName: string; profilePicture?: string; createdAt?: Date; lastSignInDate?: Date }
export type StorageErrorCode = 'invalid-id' | 'validation' | 'duplicate' | 'unavailable' | 'internal' | 'conflict' | 'forbidden' | 'test-code-unavailable' | 'not-found' | 'archived' | 'invite-unavailable' | 'last-owner' | 'snapshot-required' | 'metadata-conflict' | 'submission-conflict' | 'submission-unavailable' | 'submission-capacity' | 'command-capacity';
export class StorageError extends Error {
  constructor(code: StorageErrorCode, details?: { field?: string; scope?: 'domain' | 'node'; issues?: Array<{ field: string; message: string }> });
  code: StorageErrorCode; field?: string; scope?: 'domain' | 'node'; issues?: Array<{ field: string; message: string }>;
}
export type DomainRole = 'owner' | 'editor' | 'viewer';
export interface ActorRequirement { userId: Identifier; sessionEpoch: number; allowedRoles: DomainRole[]; allowPlatformAdmin: boolean; identityProvider?: 'staging-test' }
export interface VerifiedIdentity extends NewUser { emailVerified: true }
export interface AccessUser extends UserRecord { emailCanonical: string; emailVerified: boolean; stagingAccess?: boolean; identityProvider?: 'staging-test' }
export interface AccessControl { schemaVersion: 1 | 2; writerContract?: 'm2-a-1' | 'm2-a-1-recovery'; commandMode?: 'prepared' | 'active' | 'disabled' | 'recovering'; revision: number; planDigest: string; state: 'maintenance' | 'ready'; sessionEpoch: number; soleAdmin?: { userId: string; googleId: string; grantedAt: Date } }
export interface AccessDomain extends DomainRecord { users: Identifier[]; createdBy: Identifier; members: Record<Identifier, DomainRole>; status: 'active' | 'archived'; revision: number; invitationEpoch: number; archivedAt: Date | null; archivedBy: Identifier | null; createdAt: Date; updatedAt: Date; apiKey: string }
export interface AccessContext { control: AccessControl; user: AccessUser | null; domain: AccessDomain | null; role: DomainRole | null }
export interface PageOptions { cursor?: string; limit?: number }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface DomainMutation { domainId: Identifier; revision: number }
export interface InvitationProof { invitationId: Identifier; tokenHash: string }
export interface Invitation { _id: Identifier; domainId: Identifier; emailCanonical: string; role: DomainRole; invitationEpoch: number; revision: number; createdBy: Identifier; issuedAt: Date; expiresAt: Date; state: 'pending' | 'accepted' | 'revoked' | 'superseded'; effectiveState: 'pending' | 'accepted' | 'revoked' | 'superseded' | 'expired'; acceptedBy?: Identifier; acceptedAt?: Date }
export interface MigrationPlan { version: 1; projectId: string; databaseId: string; schemaVersion: 1; controlRevision: number | null; sessionEpoch: number; digest: string; domains: Array<{ domainId: string; createdBy: string | null; users: string[]; members: Record<string, DomainRole>; sourceDigest: string; revision: number; retiredInvite: boolean }>; users: Array<{ userId: string; googleId: string | null; emailVerified: boolean; emailCanonical: string | null; sourceDigest: string }>; blockers: Array<{ kind: string; domainId?: string; userId?: string; userIds?: string[] }>; unresolvedOwners: string[] }
export interface AccessCheck { indexes: { mode: 'emulator' | 'managed'; ready: boolean; managedVerified: boolean }; schemaVersion: number; state: string; revision: number; planDigest: string; issues: Array<{ kind: string; domainId?: string; userId?: string }> }
export interface PacketPageOptions { domainId: Identifier; from?: Date; until?: Date; cursor?: string; limit?: number }
export interface NewPacket { domain: Identifier; time: Date; packet: Buffer; meta?: PacketRecord['meta']; origin?: PacketRecord['origin'] }
export interface PacketPage { items: PacketRecord[]; nextCursor: string | null; cursor: string; from: Date; until?: Date }
export interface SessionRecord { data: Record<string, unknown>; createdAt: Date; expiresAt: Date }
export interface NodeIdentity { _id: string; domainId: string; address: number; droneId: string; createdAt: Date }
export interface DroneIdentity { _id: string; domainId: string; memberAddresses: number[]; masterAddress: number; createdAt: Date; activeCommandTransport?: 'http'; groupingRevision?: number }
export interface DroneComposition { droneId: string; revision: number; memberAddresses: number[]; masterAddress: number | null }
export interface DroneGroupingChange { sequence: number; actorId: string; committedAt: Date; before: DroneComposition[]; after: DroneComposition[] }
export interface DroneGroupingResult { sequence: number | null; destinationDroneId: string }
export type DroneGroupingDestination = { kind: 'new' } | { kind: 'existing' | 'restore'; droneId: string; expectedRevision: number; masterAddress: number };
export interface GatewayCredential { _id: string; domainId: string; name: string; nodeAddress: number; createdBy: string; createdAt: Date; revokedAt: Date | null; revision: number; fileBackup?: true }
export interface CloudNodeFileEntry { path: string; modifiedAt: Date }
export interface CloudNodeFile extends CloudNodeFileEntry { text: string; revision: string }
export interface FileBackupVersion { id: string; digest: string; capturedAt: Date; savedAt: Date }
export type MachineCredential = { kind: 'domain'; secret: string } | { kind: 'gateway'; id: string; secretHash: string };
export interface TelemetryAdmission { domainId: string; credential: MachineCredential; forwarderAddress: number; receivedAt: Date; nodeAddress?: number; receiptId?: string }
export interface ObservationOrigin { kind: 'http' | 'gateway'; forwarderAddress: number; sourceAddress?: number; gatewayId?: string }
export interface ObservationTicket { domainId: string; nodeAddress: number; generation: number; activationEpoch: string; receivedAt: Date; receiptId: string; origin: ObservationOrigin; credentialBinding: { kind: 'domain' | 'gateway'; secretHash: string; id?: string } }
export interface ObservationFacet { payload: string; lastReceivedAt: Date; receiptId: string; origin: ObservationOrigin; msgType?: number; priority?: number; writable?: boolean; valueLastChangedAt?: Date; nameLastChangedAt?: Date }
export interface ObservationNode { nodeAddress: number; generation: number; revision: number; resetAt: Date | null; resetBy: string | null; lastReceivedAt: Date | null; droneId?: string }
export interface ObservationChannel { nodeAddress: number; generation: number; channel: number; revision: number; lastReceivedAt: Date; params: Record<string, { value?: ObservationFacet; name?: ObservationFacet }> }
export interface ObservationEvent { revision: number; committedAt: Date; nodes: ObservationNode[]; channels: ObservationChannel[] }
export interface ObservationSnapshot { schemaVersion: 1; activationEpoch: string; nodes: ObservationNode[]; channels: ObservationChannel[]; startCursor: string; catchUpCursor: string | null; nextCursor: string | null }
export interface ObservationUpdates { events: ObservationEvent[]; cursor: string; caughtUp: boolean; nextCursor: string | null }
export interface CommandStateRecord {
  id: string; domainId: string; target: { nodeAddress: number; channel: number; param: number };
  operation: 'write' | 'query-value' | 'query-name'; payload: Buffer | null; msgType: number;
  transport: 'http'; priority: number; submittedBy: { userId: string; displayName: string };
  acceptedAt: Date; expiresAt: Date; state: 'pending' | 'retrieved' | 'expired' | 'cancelled' | 'superseded' | 'invalidated';
  terminalAt: Date | null; reason: string | null; cancelledBy: { userId: string; displayName: string } | null;
}
export interface CommandTarget { nodeAddress: number; channel: number; param: number }
export interface CommandExpected { observationEpoch: string; nodeGeneration: number; msgType: number; payloadBytes: number; writable: true }
export type CommandSubmission = { domainId: string; submissionId: string; target: CommandTarget } & (
  { operation: 'write'; payload: Buffer; expected: CommandExpected } |
  { operation: 'query-value' | 'query-name'; payload?: null; expected?: null });
export interface CommandSettings { httpLifetimeSeconds: number; revision: number }
export interface VoltageThresholds { redBelow: number; amberBelow: number }
export interface VisualizationSetting {
  nodeAddress: number; channel: number; moduleType: "INA219"; revision: number; thresholds: VoltageThresholds | null;
}
export interface DreamerRevision {
  modelId: string; revisionId: string; number: number; name: string; savedAt: Date;
}
export interface DreamerRevisionPage { data: DreamerRevision[]; nextCursor: string | null }
export type DreamerWater = 'salt-water' | 'freshwater';
export interface DreamerStabilitySource { domainId: string; modelId: string; revisionId: string }
export interface DreamerStabilityMetadata {
  analysisId: string; modelId: string; revisionId: string; water: DreamerWater; savedAt: Date;
}
export interface DreamerStabilityResult {
  settings: { water: DreamerWater }; equilibrium: object; [key: string]: unknown;
}
export interface DreamerStability extends DreamerStabilityMetadata { result: DreamerStabilityResult }
export interface DreamerModelDocument { name: string; [key: string]: unknown }
export interface FirestoreStore {
  visualizationSettings: {
    list(actor: ActorRequirement, input: PageOptions & { domainId: string }): Promise<Page<VisualizationSetting>>;
    save(actor: ActorRequirement, input: VisualizationSetting & { domainId: string; expectedGeneration: number }): Promise<VisualizationSetting>;
  };
  commands: {
    prepare(actor: ActorRequirement, input: { domainId: string }): Promise<{ submissionId: string; issuedAt: Date; firstUseExpiresAt: Date }>;
    lookupSubmission(actor: ActorRequirement, input: { domainId: string; submissionId: string }): Promise<{ status: 'unused'; firstUseExpiresAt: Date } | { status: 'accepted'; command: CommandStateRecord }>;
    submit(actor: ActorRequirement, input: CommandSubmission): Promise<{ created: boolean; command: CommandStateRecord }>;
    consume(machine: { credential: MachineCredential }, input: { domainId: string; nodeAddress: number; limit: number; attemptId: string; peers?: number[] }): Promise<CommandStateRecord[]>;
    cancel(actor: ActorRequirement, input: { domainId: string; commandId: string }): Promise<{ command: CommandStateRecord; cancellationApplied: boolean }>;
    list(actor: ActorRequirement, input: PageOptions & { domainId: string; view?: 'pending' | 'history'; nodeAddress?: number; channel?: number; param?: number }): Promise<Page<CommandStateRecord>>;
    getSettings(actor: ActorRequirement, input: { domainId: string }): Promise<CommandSettings>;
    updateSettings(actor: ActorRequirement, input: { domainId: string; revision: number; httpLifetimeSeconds: number }): Promise<CommandSettings>;
    get(actor: ActorRequirement, input: { domainId: string; commandId: string }): Promise<CommandStateRecord | null>;
  };
  observations: {
    enqueue(input: { ticket: ObservationTicket; packet: Buffer }): Promise<{ accepted: true }>;
    readSnapshot(actor: ActorRequirement, input: PageOptions & { domainId: string }): Promise<ObservationSnapshot>;
    readUpdates(actor: ActorRequirement, input: { domainId: string; cursor: string; through?: string; limit?: number; timeoutMs?: number; signal?: AbortSignal }): Promise<ObservationUpdates>;
    reset(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; expectedGeneration: number }): Promise<{ nodeAddress: number; generation: number; resetAt: Date; revision: number }>;
    getDiagnostics(actor: ActorRequirement, input: { domainId: string }): Promise<{ snapshotWriteFailures: number; countedThrough: Date | null }>;
  };
  telemetry: {
    admit(input: TelemetryAdmission): Promise<{ node: NodeIdentity | null; created: boolean; observationTicket?: ObservationTicket }>;
    verifyGateway(input: Omit<TelemetryAdmission, "receivedAt">): Promise<{ domainId: string; nodeAddress: number; capabilities: string[] }>;
    listIdentities(actor: ActorRequirement, input: { domainId: string }): Promise<{ nodes: NodeIdentity[]; drones: DroneIdentity[] }>;
    setDroneMaster(actor: ActorRequirement, input: { domainId: string; droneId: string; expectedRevision: number; masterAddress: number }): Promise<DroneGroupingResult>;
    moveDroneNodes(actor: ActorRequirement, input: { domainId: string; sourceDroneId: string; expectedSourceRevision: number; sourceMasterAddress: number | null;
      nodeAddresses: number[]; destination: DroneGroupingDestination }): Promise<DroneGroupingResult>;
    listDroneGroupingChanges(actor: ActorRequirement, input: { domainId: string; beforeSequence?: number; limit?: number }): Promise<{ items: DroneGroupingChange[]; nextBeforeSequence: number | null }>;
    listRestorableDrones(actor: ActorRequirement, input: PageOptions & { domainId: string; nodeAddress: number }): Promise<Page<DroneComposition & { createdAt: Date; masterAddress: number }>>;
    issueGateway(actor: ActorRequirement, input: { domainId: string; name: string; nodeAddress: number; secretHash: string; fileBackup?: boolean }): Promise<GatewayCredential>;
    listGateways(actor: ActorRequirement, input: PageOptions & { domainId: string }): Promise<Page<GatewayCredential>>;
    revokeGateway(actor: ActorRequirement, input: { domainId: string; gatewayId: string; revision: number }): Promise<GatewayCredential>;
  };
  access: { getControl(): Promise<AccessControl | null> };
  users: {
    getById(id: Identifier): Promise<AccessUser | null>;
    findByGoogleId(id: string): Promise<AccessUser | null>;
    registerVerifiedSignIn(data: VerifiedIdentity, time?: Date): Promise<AccessUser>;
    updateMapState(id: Identifier, state: MapState): Promise<AccessUser>;
  };
  domains: {
    getById(id: Identifier): Promise<AccessDomain | null>;
    getAccessContext(domainId: Identifier, userId: Identifier): Promise<AccessContext>;
    listForActor(actor: ActorRequirement, options?: PageOptions & { status?: 'active' | 'archived' }): Promise<Page<AccessDomain>>;
    createOwned(actor: ActorRequirement, input: { name: string }): Promise<AccessDomain>;
    renameAuthorized(actor: ActorRequirement, input: DomainMutation & { name: string }): Promise<AccessDomain>;
    listMembers(actor: ActorRequirement, input: PageOptions & { domainId: Identifier }): Promise<Page<UserSummary & { role: DomainRole }>>;
    changeMember(actor: ActorRequirement, input: DomainMutation & { userId: Identifier; role: DomainRole | null }): Promise<AccessDomain>;
    leave(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    archive(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    restore(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    rotateKey(actor: ActorRequirement, input: DomainMutation & { newKey: string }): Promise<AccessDomain>;
  };
  invitations: {
    issue(actor: ActorRequirement, input: { domainId: Identifier; emailCanonical: string; role: DomainRole; tokenHash: string }): Promise<Invitation>;
    reissue(actor: ActorRequirement, input: DomainMutation & { invitationId: Identifier; role: DomainRole; tokenHash: string }): Promise<Invitation>;
    revoke(actor: ActorRequirement, input: DomainMutation & { invitationId: Identifier }): Promise<Invitation>;
    list(actor: ActorRequirement, input: PageOptions & { domainId: Identifier }): Promise<Page<Invitation>>;
    inspect(proof: InvitationProof, actor: ActorRequirement): Promise<{ domainName: string; role: DomainRole; inviterDisplayName: string; expiresAt: Date }>;
    accept(actor: ActorRequirement, proof: InvitationProof): Promise<{ domainId: Identifier; role: DomainRole }>;
  };
  dreamerModels: {
    listStability(actor: ActorRequirement, input: DreamerStabilitySource & { after?: string }): Promise<{ data: DreamerStabilityMetadata[]; nextCursor: string | null }>;
    getStability(actor: ActorRequirement, input: DreamerStabilitySource & { analysisId: string }): Promise<DreamerStability>;
    saveStability(actor: ActorRequirement, input: DreamerStabilitySource & { analysisId: string; water: DreamerWater; result: DreamerStabilityResult }): Promise<DreamerStability>;
    list(actor: ActorRequirement, input: { domainId: string; after?: string }): Promise<DreamerRevisionPage>;
    revisions(actor: ActorRequirement, input: { domainId: string; modelId: string; after?: string }): Promise<DreamerRevisionPage>;
    get(actor: ActorRequirement, input: { domainId: string; modelId: string; revisionId: string }): Promise<DreamerRevision & { model: DreamerModelDocument }>;
    save(actor: ActorRequirement, input: { domainId: string; modelId: string; revisionId: string; baseRevisionId: string | null; model: DreamerModelDocument }): Promise<DreamerRevision>;
  };
  fileBackups: {
    listCloud(actor: ActorRequirement, input: { domainId: string; nodeAddress: number }): Promise<CloudNodeFileEntry[]>;
    getCloud(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; path: string }): Promise<CloudNodeFile>;
    saveCloud(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; path: string; text: string; revision: string | null }): Promise<CloudNodeFile>;
    route(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; channel: number; digest: string }):
      Promise<{ status: 'unreported' | 'mismatch' | 'unavailable' } | { status: 'matched'; text: string; capturedAt: Date }>;
    save(input: { domainId: string; nodeAddress: number; path: string; text: string; capturedAt: Date; credential: MachineCredential; forwarderAddress: number; stream: string; sequence: number }): Promise<{ status: 'saved' }>;
    list(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; path: string }): Promise<FileBackupVersion[]>;
    get(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; path: string; versionId: string }): Promise<FileBackupVersion & { text: string }>;
  };
  stagingTestSignIn?: {
    assign(actor: ActorRequirement, input: { name: string; domainId: string; role: 'editor' | 'viewer'; revision: number }): Promise<{ userId: string; domainId: string; role: 'editor' | 'viewer'; revision: number }>;
    issue(actor: ActorRequirement, input: { userId: string; recipient: string }): Promise<StagingTestSignInAudit & { code: string }>;
    redeem(input: { code: string; sessionId: string; cookie: Record<string, unknown>; csrfToken: string }): Promise<Record<string, unknown>>;
    inspect(actor: ActorRequirement, id: string): Promise<StagingTestSignInAudit>;
    revoke(actor: ActorRequirement, id: string): Promise<StagingTestSignInAudit>;
  };
  sessions: {
    get(id: string, now?: Date): Promise<SessionRecord | null>;
    put(id: string, value: SessionRecord): Promise<void>;
    remove(id: string): Promise<void>;
  };
  replay: {
    inspect(actor: ActorRequirement, input: { domainId: Identifier; at?: number }): Promise<ReplaySettings & { preparedUntil: number | null; requestedUntil: number | null; ready?: boolean }>;
    setInterval(actor: ActorRequirement, input: { domainId: Identifier; intervalMs: number; revision: number }): Promise<ReplaySettings>;
    frame(actor: ActorRequirement, input: { domainId: Identifier; at: number; includeProgress?: boolean; exact?: boolean }): Promise<{ until: number; payload: Buffer } | null>;
    request(actor: ActorRequirement, input: { domainId: Identifier; from: number; until: number; follow?: boolean }): Promise<{ preparedUntil: number | null; requestedUntil: number }>;
    requestAnchor(actor: ActorRequirement, input: { domainId: Identifier; from: number; at: number }): Promise<{ ready: boolean }>;
    publishBoundary(input: { domainId: Identifier; anchorAt?: number | null; token: string; until: number; payload: Buffer }): Promise<void>;
    claim(): Promise<ReplayWork | null>;
    checkpoint(input: { domainId: Identifier; token: string; anchorAt?: number | null } & (
      { until: number; cursor?: string | null; boundaryAt?: number | null; payload: Buffer; capture?: boolean; target?: number } | { retry: true }
    )): Promise<{ preparedUntil: number | null; captured: boolean } | null>;
    listBookmarks(actor: ActorRequirement, input: { domainId: Identifier; cursor?: string; limit?: number }): Promise<{ items: ReplayBookmark[]; nextCursor: string | null }>;
    createBookmark(actor: ActorRequirement, input: { domainId: Identifier; at: number; note: string; payload?: Buffer }): Promise<ReplayBookmark>;
    changeBookmark(actor: ActorRequirement, input: { domainId: Identifier; id: string } & ({ note: string } | { remove: true })): Promise<ReplayBookmark | null>;
  };
  packets: {
    bounds(domainId: Identifier): Promise<{ first: number | null; last: number | null }>;
    enqueue(data: NewPacket): Promise<{ accepted: true; packetId: string }>;
    readPage(options: PacketPageOptions): Promise<PacketPage>;
    waitForPage(options: PacketPageOptions & { timeoutMs?: number; signal?: AbortSignal }): Promise<PacketPage>;
    countRetained(domainId: Identifier): Promise<number>;
  };
  close(): Promise<void>;
}
export interface ReplaySettings { intervalMs: number; settingsRevision: number }
export interface ReplayBookmark { id: string; at: number; authorId: Identifier; note: string }
export interface ReplayWork extends ReplaySettings {
  domainId: Identifier; token: string; from: number; target: number; follow: boolean;
  anchorAt: number | null; boundaryAt: number | null; preparedUntil: number | null; lastCapture: number; pendingUntil: number | null; cursor: string | null; payload: Buffer | null;
}
export interface StagingTestSignInAudit {
  _id: string; userId: string; issuerId: string; recipient: string; issuedAt: Date; codeExpiresAt: Date; sessionEpoch: number;
  redeemedAt?: Date; sessionExpiresAt?: Date; revokedAt?: Date; revokedBy?: string; revocationReason?: 'admin' | 'session-ended';
}
export interface FirestoreOptions {
  stagingTestSignIn?: boolean;
  fileBackupLimit?: number;
  projectId: string; databaseId?: string; emulatorHost?: string;
  commandContract?: 'm2-a-1'; commandClock?: () => Date;
  observationEpoch?: string; observationFlushIntervalMs?: number; observationMaxBufferBytes?: number; observationRetentionMs?: number;
  flushIntervalMs?: number; maxChunkPackets?: number; maxChunkBytes?: number; maxBufferBytes?: number;
  writeTimeoutMs?: number; onPacketDrop?: (event: { domainId: string; packetCount: number; category: string }) => void;
}
export function openFirestoreStore(options: FirestoreOptions): Promise<FirestoreStore>;

export type Store = FirestoreStore;
