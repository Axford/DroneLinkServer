// Optional Node-only compatibility harness. Production entrypoints never import this module.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

export const vectors = JSON.parse(readFileSync(new URL('../fixtures.json', import.meta.url))).vectors;
const bytes = vector => Uint8Array.from(vector.decoded.payload);
export const rawBytes = vector => Uint8Array.from(Buffer.from(vector.hex.replaceAll(' ', ''), 'hex'));

export function encodeVector(Codec, vector) {
  const msg = new Codec();
  const d = vector.decoded;
  switch (d.msgType) {
    case 0: msg.setUint8(d.values); break;
    case 1: msg.setAddr(d.payload); break;
    case 2: msg.setUint32(d.values); break;
    case 3: msg.setFloat(d.values); break;
    case 4:
    case 5:
      // Use the raw single-byte string, including bytes after NUL, when encoding.
      msg.setString(String.fromCharCode(...d.payload));
      msg.msgType = d.msgType;
      break;
    default: throw new Error('Fixture outside supported subset');
  }
  for (const name of ['source','node','channel','param','priority','writable']) msg[name] = d[name];
  return msg;
}

export function assertDecoded(msg, vector) {
  const d = vector.decoded;
  for (const name of ['source','node','channel','param','priority','msgType','writable']) {
    assert.equal(msg[name], d[name], `${vector.name}: ${name}`);
  }
  assert.equal(msg.msgLength, d.payload.length, vector.name);
  assert.equal(msg.totalSize(), d.payload.length + 5, vector.name);
  assert.deepEqual(msg.encodeUnframed(), rawBytes(vector), vector.name);
  if (d.msgType === 4 || d.msgType === 5) assert.equal(msg.payloadToString(), d.values[0], vector.name);
  else assert.deepEqual(Array.from(msg.valueArray()), d.msgType === 1 ? Array.from(bytes(vector)) : d.values, vector.name);
}

export function registerCodecTests(Codec, label) {
  for (const vector of vectors) {
    test(`${label}: ${vector.name}: decode, encode and round trip`, () => {
      assertDecoded(new Codec(rawBytes(vector).buffer), vector);
      const encoded = encodeVector(Codec, vector).encodeUnframed();
      assert.deepEqual(encoded, rawBytes(vector), vector.name);
      assertDecoded(new Codec(encoded.buffer), vector);
    });
  }
  test(`${label}: every priority and writable combination preserves all parameter bits`, () => {
    for (let priority = 0; priority < 4; priority++) for (const writable of [false,true]) {
      const msg = new Codec();
      msg.setUint8([255]);
      Object.assign(msg, {source:255,node:255,channel:255,param:63,priority,writable});
      const expected = Uint8Array.from([255,255,255,(priority << 6)|63,writable ? 128 : 0,255]);
      assert.deepEqual(msg.encodeUnframed(), expected);
      const decoded = new Codec(expected.buffer);
      assert.equal(decoded.priority, priority);
      assert.equal(decoded.writable, writable);
      assert.equal(decoded.param, 63);
    }
  });
  test(`${label}: characterization only: truncated payload zero-fills; trailing bytes ignored`, () => {
    assert.deepEqual(new Codec(Uint8Array.from([0,1,1,1,3,42]).buffer).valueArray(), [42,0,0,0]);
    assert.deepEqual(new Codec(Uint8Array.from([0,1,1,1,0,42,99]).buffer).valueArray(), [42]);
    const shortHeader = new Codec(Uint8Array.from([0,1]).buffer);
    assert.equal(shortHeader.msgLength, 1);
    assert.deepEqual(shortHeader.valueArray(), [0]);
  });
  test(`${label}: characterization only: misaligned uint32 length is retained; value view ignores partial element`, () => {
    const msg = new Codec(Uint8Array.from([0,1,1,1,0x22,1,2,3]).buffer);
    assert.equal(msg.msgLength, 3);
    assert.deepEqual(Array.from(msg.valueArray()), []);
    assert.deepEqual(msg.encodeUnframed(), Uint8Array.from([0,1,1,1,0x22,1,2,3]));
  });
  test(`${label}: characterization only: ADDR value helper returns first entry; raw bytes retain both`, () => {
    const raw = Uint8Array.from([0,1,1,1,0x17,0,2,3,4,0,5,6,7]);
    const msg = new Codec(raw.buffer);
    assert.deepEqual(msg.valueArray(), [0,2,3,4]);
    assert.deepEqual(msg.encodeUnframed(), raw);
    const set = new Codec();
    set.setAddr([0,2,3,4,0,5,6,7]);
    assert.equal(set.msgLength, 4);
    assert.deepEqual(set.encodeUnframed().subarray(5), Uint8Array.from([0,2,3,4]));
  });
}
