/// <reference types="node" />
export type Identifier = string;
export interface MapState { lng: number; lat: number; zoom: number }
export interface UserSummary { _id: Identifier; displayName: string; email: string; profilePicture?: string }
export interface UserRecord extends UserSummary {
  googleId: string; domains: Identifier[]; mapState?: MapState; createdAt?: Date; lastSignInDate?: Date; __v?: number;
}
export interface DomainRecord {
  _id: Identifier; name: string; apiKey?: string; inviteToken?: string;
  users: Array<Identifier | UserSummary>; createdBy?: Identifier | UserSummary | null;
  createdAt?: Date | string; updatedAt?: Date | string; stats?: { nodeCount: number; packetCount: number }; __v?: number;
}
export interface InvitePreviewRecord { _id: Identifier; name: string; createdBy?: UserSummary | null; createdAt?: Date }
export interface PacketRecord {
  _id: Identifier; time: Date; domain: Identifier; packet?: Buffer | null;
  meta?: { id?: number; node?: number; channel?: number; param?: number; msgType?: number; source?: number };
  origin?: { kind: 'http' | 'gateway'; gatewayId?: string }; __v?: number;
}
export interface NewUser { email: string; googleId: string; displayName: string; profilePicture?: string; createdAt?: Date; lastSignInDate?: Date }
export type StorageErrorCode = 'invalid-id' | 'validation' | 'duplicate' | 'unavailable' | 'internal' | 'conflict' | 'forbidden' | 'not-found' | 'archived' | 'invite-unavailable' | 'last-owner' | 'snapshot-required';
export class StorageError extends Error {
  constructor(code: StorageErrorCode, details?: { field?: string; issues?: Array<{ field: string; message: string }> });
  code: StorageErrorCode; field?: string; issues?: Array<{ field: string; message: string }>;
}
export type DomainRole = 'owner' | 'editor' | 'viewer';
export interface ActorRequirement { userId: Identifier; sessionEpoch: number; allowedRoles: DomainRole[]; allowPlatformAdmin: boolean }
export interface VerifiedIdentity extends NewUser { emailVerified: true }
export interface AccessUser extends UserRecord { emailCanonical: string; emailVerified: boolean; stagingAccess?: boolean }
export interface AccessControl { schemaVersion: 1; revision: number; planDigest: string; state: 'maintenance' | 'ready'; sessionEpoch: number; soleAdmin?: { userId: string; googleId: string; grantedAt: Date } }
export interface AccessDomain extends DomainRecord { users: Identifier[]; createdBy: Identifier; members: Record<Identifier, DomainRole>; status: 'active' | 'archived'; revision: number; invitationEpoch: number; archivedAt: Date | null; archivedBy: Identifier | null; createdAt: Date; updatedAt: Date; apiKey: string }
export interface AccessContext { control: AccessControl; user: AccessUser | null; domain: AccessDomain | null; role: DomainRole | null }
export interface PageOptions { cursor?: string; limit?: number }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface DomainMutation { domainId: Identifier; revision: number }
export interface InvitationProof { invitationId: Identifier; tokenHash: string }
export interface Invitation { _id: Identifier; domainId: Identifier; emailCanonical: string; role: DomainRole; invitationEpoch: number; revision: number; createdBy: Identifier; issuedAt: Date; expiresAt: Date; state: 'pending' | 'accepted' | 'revoked' | 'superseded'; effectiveState: 'pending' | 'accepted' | 'revoked' | 'superseded' | 'expired'; acceptedBy?: Identifier; acceptedAt?: Date }
export interface MigrationPlan { version: 1; projectId: string; databaseId: string; schemaVersion: 1; controlRevision: number | null; sessionEpoch: number; digest: string; domains: Array<{ domainId: string; createdBy: string | null; users: string[]; members: Record<string, DomainRole>; sourceDigest: string; revision: number; retiredInvite: boolean }>; users: Array<{ userId: string; googleId: string | null; emailVerified: boolean; emailCanonical: string | null; sourceDigest: string }>; blockers: Array<{ kind: string; domainId?: string; userId?: string; userIds?: string[] }>; unresolvedOwners: string[] }
export interface AccessCheck { indexes: { mode: 'emulator' | 'managed'; ready: boolean; managedVerified: boolean }; schemaVersion: number; state: string; revision: number; planDigest: string; issues: Array<{ kind: string; domainId?: string; userId?: string }> }
export interface PacketPageOptions { domainId: Identifier; from?: Date; until?: Date; cursor?: string; limit?: number }
export interface NewPacket { domain: Identifier; time: Date; packet: Buffer; meta?: PacketRecord['meta']; origin?: PacketRecord['origin'] }
export interface PacketPage { items: PacketRecord[]; nextCursor: string | null; cursor: string; from: Date; until?: Date }
export interface SessionRecord { data: Record<string, unknown>; createdAt: Date; expiresAt: Date }
export interface NodeIdentity { _id: string; domainId: string; address: number; droneId: string; createdAt: Date }
export interface DroneIdentity { _id: string; domainId: string; memberAddresses: number[]; masterAddress: number; createdAt: Date }
export interface GatewayCredential { _id: string; domainId: string; name: string; nodeAddress: number; createdBy: string; createdAt: Date; revokedAt: Date | null; revision: number }
export type MachineCredential = { kind: 'domain'; secret: string } | { kind: 'gateway'; id: string; secretHash: string };
export interface TelemetryAdmission { domainId: string; credential: MachineCredential; forwarderAddress: number; receivedAt: Date; nodeAddress?: number; receiptId?: string }
export interface ObservationOrigin { kind: 'http' | 'gateway'; forwarderAddress: number; sourceAddress?: number; gatewayId?: string }
export interface ObservationTicket { domainId: string; nodeAddress: number; generation: number; activationEpoch: string; receivedAt: Date; receiptId: string; origin: ObservationOrigin; credentialBinding: { kind: 'domain' | 'gateway'; secretHash: string; id?: string } }
export interface ObservationFacet { payload: string; lastReceivedAt: Date; receiptId: string; origin: ObservationOrigin; msgType?: number; writable?: boolean; valueLastChangedAt?: Date; nameLastChangedAt?: Date }
export interface ObservationNode { nodeAddress: number; generation: number; revision: number; resetAt: Date | null; resetBy: string | null; lastReceivedAt: Date | null; droneId?: string }
export interface ObservationChannel { nodeAddress: number; generation: number; channel: number; revision: number; lastReceivedAt: Date; params: Record<string, { value?: ObservationFacet; name?: ObservationFacet }> }
export interface ObservationEvent { revision: number; committedAt: Date; nodes: ObservationNode[]; channels: ObservationChannel[] }
export interface ObservationSnapshot { schemaVersion: 1; activationEpoch: string; nodes: ObservationNode[]; channels: ObservationChannel[]; startCursor: string; catchUpCursor: string | null; nextCursor: string | null }
export interface ObservationUpdates { events: ObservationEvent[]; cursor: string; caughtUp: boolean; nextCursor: string | null }
export interface FirestoreStore {
  observations: {
    enqueue(input: { ticket: ObservationTicket; packet: Buffer }): Promise<{ accepted: true }>;
    readSnapshot(actor: ActorRequirement, input: PageOptions & { domainId: string }): Promise<ObservationSnapshot>;
    readUpdates(actor: ActorRequirement, input: { domainId: string; cursor: string; through?: string; limit?: number; timeoutMs?: number; signal?: AbortSignal }): Promise<ObservationUpdates>;
    reset(actor: ActorRequirement, input: { domainId: string; nodeAddress: number; expectedGeneration: number }): Promise<{ nodeAddress: number; generation: number; resetAt: Date; revision: number }>;
    getDiagnostics(actor: ActorRequirement, input: { domainId: string }): Promise<{ snapshotWriteFailures: number; countedThrough: Date | null }>;
  };
  telemetry: {
    admit(input: TelemetryAdmission): Promise<{ node: NodeIdentity | null; created: boolean; observationTicket?: ObservationTicket }>;
    verifyGateway(input: Omit<TelemetryAdmission, "receivedAt">): Promise<{ domainId: string; nodeAddress: number; capabilities: string[] }>;
    listIdentities(actor: ActorRequirement, input: { domainId: string }): Promise<{ nodes: NodeIdentity[]; drones: DroneIdentity[] }>;
    issueGateway(actor: ActorRequirement, input: { domainId: string; name: string; nodeAddress: number; secretHash: string }): Promise<GatewayCredential>;
    listGateways(actor: ActorRequirement, input: PageOptions & { domainId: string }): Promise<Page<GatewayCredential>>;
    revokeGateway(actor: ActorRequirement, input: { domainId: string; gatewayId: string; revision: number }): Promise<GatewayCredential>;
  };
  access: { getControl(): Promise<AccessControl | null> };
  users: {
    getById(id: Identifier): Promise<AccessUser | null>;
    findByGoogleId(id: string): Promise<AccessUser | null>;
    registerVerifiedSignIn(data: VerifiedIdentity, time?: Date): Promise<AccessUser>;
    updateMapState(id: Identifier, state: MapState): Promise<AccessUser>;
  };
  domains: {
    getById(id: Identifier): Promise<AccessDomain | null>;
    getAccessContext(domainId: Identifier, userId: Identifier): Promise<AccessContext>;
    listForActor(actor: ActorRequirement, options?: PageOptions & { status?: 'active' | 'archived' }): Promise<Page<AccessDomain>>;
    createOwned(actor: ActorRequirement, input: { name: string }): Promise<AccessDomain>;
    renameAuthorized(actor: ActorRequirement, input: DomainMutation & { name: string }): Promise<AccessDomain>;
    listMembers(actor: ActorRequirement, input: PageOptions & { domainId: Identifier }): Promise<Page<UserSummary & { role: DomainRole }>>;
    changeMember(actor: ActorRequirement, input: DomainMutation & { userId: Identifier; role: DomainRole | null }): Promise<AccessDomain>;
    leave(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    archive(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    restore(actor: ActorRequirement, input: DomainMutation): Promise<AccessDomain>;
    rotateKey(actor: ActorRequirement, input: DomainMutation & { newKey: string }): Promise<AccessDomain>;
  };
  invitations: {
    issue(actor: ActorRequirement, input: { domainId: Identifier; emailCanonical: string; role: DomainRole; tokenHash: string }): Promise<Invitation>;
    reissue(actor: ActorRequirement, input: DomainMutation & { invitationId: Identifier; role: DomainRole; tokenHash: string }): Promise<Invitation>;
    revoke(actor: ActorRequirement, input: DomainMutation & { invitationId: Identifier }): Promise<Invitation>;
    list(actor: ActorRequirement, input: PageOptions & { domainId: Identifier }): Promise<Page<Invitation>>;
    inspect(proof: InvitationProof, actor: ActorRequirement): Promise<{ domainName: string; role: DomainRole; inviterDisplayName: string; expiresAt: Date }>;
    accept(actor: ActorRequirement, proof: InvitationProof): Promise<{ domainId: Identifier; role: DomainRole }>;
  };
  sessions: {
    get(id: string, now?: Date): Promise<SessionRecord | null>;
    put(id: string, value: SessionRecord): Promise<void>;
    remove(id: string): Promise<void>;
  };
  packets: {
    enqueue(data: NewPacket): Promise<{ accepted: true; packetId: string }>;
    readPage(options: PacketPageOptions): Promise<PacketPage>;
    waitForPage(options: PacketPageOptions & { timeoutMs?: number; signal?: AbortSignal }): Promise<PacketPage>;
    countRetained(domainId: Identifier): Promise<number>;
  };
  close(): Promise<void>;
}
export interface FirestoreOptions {
  projectId: string; databaseId?: string; emulatorHost?: string;
  observationEpoch?: string; observationFlushIntervalMs?: number; observationMaxBufferBytes?: number; observationRetentionMs?: number;
  flushIntervalMs?: number; maxChunkPackets?: number; maxChunkBytes?: number; maxBufferBytes?: number;
  writeTimeoutMs?: number; onPacketDrop?: (event: { domainId: string; packetCount: number; category: string }) => void;
}
export function openFirestoreStore(options: FirestoreOptions): Promise<FirestoreStore>;

export type Store = FirestoreStore;
