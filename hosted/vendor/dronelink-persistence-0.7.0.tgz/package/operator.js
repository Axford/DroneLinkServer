'use strict';
// Separate privileged composition; importing either entry point starts no resources.
module.exports = { openCommandOperatorStore: options => require('./lib/firestore').openCommandOperatorStore(options), openAccessOperatorStore: options => require('./lib/firestore').openAccessOperatorStore(options) };
