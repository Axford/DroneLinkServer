# @dronelink/persistence

Backend-only native Firestore storage operations. Server owns HTTP, Google identity, permissions and deployment; this package is a library, not another service. See the [storage contract](../../docs/contracts/storage.md#sep-06-native-firestore-contract--in-progress) and [SEP-06](../../docs/planning/repository-separation.md#sep-06-planning-decisions--2026-11-06).

## Source and releases

0.2.0 is the native source candidate. Hosted remains on its independently retained MongoDB 0.1.2 archive until explicit adoption. Do not overwrite any 0.1.x archive. The candidate exports only `openFirestoreStore` and `StorageError`; MongoDB is no longer an active source dependency or factory. SEP-04 tests/fixtures and `lib/models.js` remain historical references, excluded from the new runtime archive. Their original runnable environment is retained by Git and the immutable old releases.

Node 22+ is required by the pinned Firestore SDK 9.4.0. Production uses `npm ci --omit=dev`, explicit project/database settings and managed credentials. Imports open nothing. No Firebase browser SDK, emulator, Java, gateway or MongoDB installation is required by production.

## Development checks

Java 21 is required only to run the disposable Firestore emulator. Preparation explicitly downloads a SHA-256-pinned emulator 1.22.0; install and tests never download it automatically:

```sh
npm ci
npm run test:firestore:prepare
npm test
npm run test:storage
```

Preparation can copy matching bytes from an explicit cache using `npm run test:firestore:prepare -- --from /absolute/cloud-firestore-emulator-v1.22.0.jar`. Tests launch owned loopback-only Java processes with generated `demo-sep06-*` project IDs and clean them up. They do not accept a live project/database override. The native interface suite uses actual storage for management transactions, session sharing/expiry/logout, packet chunks/counts/cursor edges, listener cancellation, overload and database-outage loss. Public declarations and four Python release-integrity cases also run through `npm test`. Managed indexes, Google, full browser and deployment acceptance remain separate SEP-06 gates.

## Interface

`openFirestoreStore({projectId, databaseId, ...})` returns users/domains/sessions/packets/close. Production selects `(default)` explicitly. Local tests explicitly supply a loopback `emulatorHost`; ambient emulator redirection is rejected. Returned records contain strings, Dates, Buffers and plain objects; no driver queries/references/snapshots escape. `StorageError` carries neutral codes/details.

Management operations own atomic related writes with revision/token preconditions; Server chooses and authorizes them. Domain deletion retains packets. Domain listing is scoped newest-first cursor paging. Sessions have immutable expiry for a given identity, checked on read; logout prevents revival by a concurrent save. Server owns session lifetime/admission/cookie policy.

Packets acknowledge volatile buffer admission, group immutable receipt-second chunks and expose individual records via history/live cursors. Buffer admission is bounded; actual telemetry write RPC deadlines are bounded, failed chunks are logged/dropped without an application retry queue, and close attempts a bounded flush. `waitForPage` detaches listeners on timeout/abort/close. Counts sum persisted packet totals, never chunks or unflushed data. The package's `firestore.indexes.json` declares managed query indexes, packet/session payload exemptions and session-only TTL.

## Publication and rollback

Commit source/tests/docs before `npm run pack:release`. The release tool verifies source Git bytes, archive member set and hashes, then publishes immutable local archive/provenance files; it never publishes to a registry or mutates a sibling checkout. `npm run check:release` verifies a published identity by repacking. Explicitly copy a reviewed archive into Server's vendor directory and update its manifest/lock together.

Keep matched backend/Client/storage/configuration identities. Application rollback selects a compatible Firestore release and preserves current data. A MongoDB release is historical evidence, not a Firestore-compatible runtime fallback. Restoring an archive is a separate recovery operation; no restore rehearsal is required by SEP-06.
