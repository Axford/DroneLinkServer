#!/usr/bin/env python3
"""Run real DroneLinkMsg.cpp and packed structs on the host, with I/O/platform stubs.

This exercises no device, transport, ESP32 toolchain, web server or real logging.
"""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile
from build import ROOT, firmware_definitions

STUB = r'''
#pragma once
#include <cstdint>
#include <cstring>
#include <cmath>
#include <string>
using boolean = bool;
#define __packed __attribute__((packed))
#define F(x) x
class String {
  std::string value;
public:
  String(std::string v = "") : value(v) {}
  int indexOf(const char* s) const { auto p = value.find(s); return p == std::string::npos ? -1 : int(p); }
  String substring(int first, int last) const { return String(value.substr(first, last-first)); }
  String substring(int first) const { return String(value.substr(first)); }
  long toInt() const { return std::strtol(value.c_str(), nullptr, 10); }
  unsigned length() const { return value.size(); }
};
class HostPrint {
public:
  template<class... Args> void print(Args...) {}
  template<class... Args> void println(Args...) {}
  template<class... Args> void printf(Args...) {}
};
inline HostPrint Serial;
using std::isnan;
using std::isinf;
using std::fabs;
'''


def source(constants, sizes, vectors):
    lines = ['#include "DroneLinkMsg.h"', '#include "protocol.h"', '#include <cassert>', '#include <cstddef>',
             'static_assert(sizeof(DRONE_LINK_ADDR) == 4);',
             'static_assert(sizeof(DRONE_LINK_PAYLOAD) == 16);',
             'static_assert(sizeof(DRONE_LINK_MSG) == 21);',
             'static_assert(offsetof(DRONE_LINK_MSG, payload) == 5);',
             'static_assert(sizeof(float) == 4);']
    for key in constants:
        if key.startswith('DRONE_MODULE_') or key == 'DRONE_LINK_MSG_HEADER_BYTES':
            continue  # Module constants are verified from headers by the generator, not by stubbing DroneModule.
        lines.append(f'static_assert({key} == dronelink_reference::reference_{key});')
    lines += ['int main() {']
    for i,value in enumerate(sizes):
        lines.append(f'assert(DRONE_LINK_MSG_TYPE_SIZES[{i}] == {value});')
    for vector in vectors:
        d = vector['decoded']
        lines += ['{', f'// {vector["name"]}', 'DroneLinkMsg msg; msg._msg = {};']
        for setter,key in [('source','source'),('node','node'),('channel','channel'),('param','param'),('priority','priority'),('type','msgType')]:
            lines.append(f'msg.{setter}({d[key]});')
        lines += [f'msg.length({len(d["payload"])});', f'msg.writable({str(d["writable"]).lower()});']
        if d['msgType'] in (2,3):
            member = 'uint32' if d['msgType'] == 2 else 'f'
            for i,value in enumerate(d['values']):
                lines.append(f'msg._msg.payload.{member}[{i}] = {value}{"u" if member == "uint32" else ""};')
        elif d['msgType'] == 1:
            a=d['values'][0]
            for field in ['source','node','channel']:
                lines.append(f'msg._msg.payload.addr[0].{field} = {a[field]};')
            lines.append(f'msg._msg.payload.addr[0].paramPriority = setDroneLinkMsgPriorityParam({a["priority"]}, {a["param"]});')
        else:
            for i,value in enumerate(d['payload']):
                lines.append(f'msg._msg.payload.uint8[{i}] = {value};')
        expected = list(bytes.fromhex(vector['hex']))
        lines += ['const uint8_t expected[] = {'+', '.join(map(str,expected))+'};',
                  'assert(msg.totalSize() == sizeof(expected));',
                  'assert(std::memcmp(&msg._msg, expected, sizeof(expected)) == 0);',
                  f'assert(msg.packParamLength({str(d["writable"]).lower()}, {d["msgType"]}, {len(d["payload"])}) == expected[4]);',
                  'DRONE_LINK_MSG wire{}; std::memcpy(&wire, expected, sizeof(expected));',
                  'DroneLinkMsg decoded(&wire);']
        for getter,key in [('source','source'),('node','node'),('channel','channel'),('param','param'),('priority','priority'),('type','msgType'),('writable','writable')]:
            value = str(d[key]).lower() if isinstance(d[key],bool) else d[key]
            lines.append(f'assert(decoded.{getter}() == {value});')
        lines.append(f'assert(decoded.length() == {len(d["payload"])});')
        if d['msgType'] in (2,3):
            member = 'uint32' if d['msgType'] == 2 else 'f'
            for i,value in enumerate(d['values']):
                lines.append(f'assert(decoded._msg.payload.{member}[{i}] == {value}{"u" if member == "uint32" else ""});')
        lines += ['}']
    # Exercise all four packed ADDR entries through the unchanged real message class.
    lines += ['{ DroneLinkMsg msg; msg._msg = {};', 'msg.type(DRONE_LINK_MSG_TYPE_ADDR); msg.length(16);',
              'for (int i = 0; i < 4; ++i) {', 'msg._msg.payload.addr[i] = {uint8_t(i), uint8_t(i+1), uint8_t(i+2), uint8_t(0xC0+i)};', '}',
              'const uint8_t expected[] = {0,1,2,192, 1,2,3,193, 2,3,4,194, 3,4,5,195};',
              'assert(msg.length() == 16); assert(msg.totalSize() == 21);',
              'assert(std::memcmp(&msg._msg.payload, expected, 16) == 0); }']
    lines += ['return 0;', '}']
    return '\n'.join(lines)+'\n'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--firmware', type=Path, help='Optional live checkout; must match frozen snapshot')
    args=parser.parse_args()
    provenance, constants, sizes=firmware_definitions()
    firmware=ROOT/'firmware'
    if args.firmware:
        import hashlib
        for path,item in provenance['files'].items():
            assert hashlib.sha256((args.firmware/path).read_bytes()).hexdigest() == item['sha256'], f'{path}: live source differs; review required'
        firmware=args.firmware.resolve()/'src'
    vectors=json.loads((ROOT/'fixtures.json').read_text())['vectors']
    with tempfile.TemporaryDirectory(prefix='dronelink-firmware-') as directory:
        tmp=Path(directory)
        (tmp/'Arduino.h').write_text(STUB)
        (tmp/'ArduinoLog.h').write_text('#pragma once\n')
        (tmp/'ESPAsyncWebServer.h').write_text('#pragma once\n#include "Arduino.h"\nclass AsyncResponseStream : public HostPrint {};\n')
        (tmp/'check.cpp').write_text(source(constants,sizes,vectors))
        subprocess.run(['c++','-std=c++17','-Wall','-Wextra','-Wno-unused-parameter', '-I',str(tmp),'-I',str(firmware),'-I',str(ROOT/'dist'), str(tmp/'check.cpp'),str(firmware/'DroneLinkMsg.cpp'),'-o',str(tmp/'check')], check=True)
        subprocess.run([str(tmp/'check')], check=True)
    print(f'PASS: actual firmware message implementation, packed layout, constants and {len(vectors)} fixtures on host; platform/I/O stubs, no hardware')


if __name__ == '__main__':
    main()
