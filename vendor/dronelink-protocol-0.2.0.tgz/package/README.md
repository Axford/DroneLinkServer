# @dronelink/protocol

Portable DroneLink constants, TypeScript declarations and independent packet fixtures. Version 0.2.0 is distributed as a pinned local npm archive; no registry publication is required. There are no runtime dependencies. This package defines no new wire version and adds a shared structural validation kernel without changing valid wire bytes.

Firmware is authoritative. `firmware/provenance.json` identifies the upstream commit, exact frozen bytes/checksums including the committed checked-copy guard. Headers and the relevant message implementation are included for reproducible host verification. Generated C++ definitions are comparison-only; firmware does not adopt this package.

```sh
npm run build
npm test
npm run test:firmware
npm run pack:release
```

Generation reads only frozen package inputs and writes only this package. `python3 tools/build.py --check --firmware /path/to/DroneNode` explicitly compares the live checkout read-only. `python3 tools/check_firmware.py --firmware /path/to/DroneNode` compiles the live matching firmware message source with platform/I/O stubs on the host. Neither command runs PlatformIO or its sibling-writing post-build hook.

Compatibility coverage includes valid unframed packets, 1–16 payload bytes, uint8/uint32/float arrays, 1–4 ADDR entries and single-byte CHAR/NAME strings with existing NUL trimming. Fixtures specify expected bytes independently of production codecs. `@dronelink/protocol/testing` is an optional Node-only conformance harness; it is separate from the browser-safe package entrypoint.

Query payloads include at least one ignored byte. The strict corpus includes query types and malformed boundaries. Firmware runtime/transport/device acceptance is tracked separately in the owning M1 plan; this package host harness does not execute on ESP32. Unicode migration remains outside scope.

Consume the exact archive through a local `file:vendor/dronelink-protocol-0.2.0.tgz` dependency and its lockfile. Keep previous archives with the matching consumer source/lockfiles for rollback. Never replace an existing version with different bytes. A release check rebuilds and compares the archive; changes require a new package version and reviewed provenance. Release generation never copies into sibling repositories.


Protocol0.1.2 retains the same firmware snapshots, wire constants and16 valid unframed fixtures. Its optional conformance harness now verifies corrected1–4 ADDR helpers, complete legacy link framing/CRC and unsigned low32-bit log timestamp reads. Log bytes/time-base and permissive raw-parser/single-byte string semantics are unchanged; this is not a firmware or serial-mesh format release. Gateway/Client consume0.1.2; the independently deployed hosted backend retains0.1.1 with identical constants. Original0.1.0/0.1.1 archives are preserved.

## Strict validation in 0.2.0

Browser-safe `readLinkPacket`/`encodeLinkPacket`, typed/text payload builders and log helpers throw `ProtocolValidationError extends RangeError`. Complete headers, exact 6–21-byte packets and 4-byte numeric/address alignment are mandatory. Header fields and typed inputs are checked before coercion. ArrayBuffer views use their visible byte window; decoded payloads own their bytes. Reserved addresses and float NaN/Infinity remain representable. QUERY/NAMEQUERY allow 1–16 ignored bytes. Text remains single-byte, at most 16 bytes, with empty text represented by one NUL byte.

`readLinkLog` requires an exact 11–26-byte record; timestamp serialization accepts a nonnegative safe integer and writes its low32 bits big-endian. File boundary recovery and degraded/live state diagnostics remain consumer responsibilities. `validation-vectors.json` is shared with the real firmware checked-copy test. Earlier immutable archives retain their original behavior and harnesses.
