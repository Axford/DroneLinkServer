#!/usr/bin/env python3
"""Create/check a deterministic local archive; never publish or update consumers."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
from build import ROOT

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--check',action='store_true')
args=parser.parse_args()
subprocess.run(['python3',str(ROOT/'tools/build.py'),'--check'],check=True)
version=json.loads((ROOT/'package.json').read_text())['version']
with tempfile.TemporaryDirectory(prefix='dronelink-pack-') as directory:
    result=subprocess.run(['npm','pack','--ignore-scripts','--json','--pack-destination',directory,'--cache',directory+'/cache'],cwd=ROOT,check=True,text=True,capture_output=True)
    filename=json.loads(result.stdout)[0]['filename']
    raw=(Path(directory)/filename).read_bytes()
    target=ROOT/'releases'/filename
    if args.check or target.exists():
        assert target.read_bytes() == raw, f'{target}: release differs; never overwrite a released version'
    else:
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(raw)
    manifest={'package':'@dronelink/protocol','version':version,'archive':filename,'sha256':hashlib.sha256(raw).hexdigest()}
    path=ROOT/'releases'/f'{version}.json'
    content=json.dumps(manifest,indent=2)+'\n'
    if args.check or path.exists():
        assert path.read_text() == content, 'Release manifest differs'
    else:
        path.write_text(content)
    print(f'PASS: reproducible {filename}, sha256={manifest["sha256"]}')
