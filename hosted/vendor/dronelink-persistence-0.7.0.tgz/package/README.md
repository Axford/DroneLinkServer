# @dronelink/persistence

Backend-only native Firestore operations. Server owns HTTP, Google verification, policy and deployment. This library opens no resources at import. Node22+, explicit project/database and managed credentials are required; Java21/the pinned emulator are development-only.

## Access-control source and adoption

0.3.0 implements [M1 A.1](../../docs/planning/m1-contracts-and-telemetry.md#slice-a-implementation-plan--2026-11-06): verified stable identities, transactional domain/member/role/key/lifecycle operations and targeted seven-day invitations. It replaces the membership-only interface and must not be installed into an old hosted application. Server currently retains its immutable0.2.0 runtime pin; the separately installed operator tool adopts0.3.0 first. The coordinated Server/Client/schema transition remains A.2–A.4. Keep all prior immutable archives.

`openFirestoreStore({projectId,databaseId,...})` returns `users,access,domains,invitations,sessions,packets,close`. It exposes no migration, grant, recovery or permanent deletion method. Server supplies trusted `ActorRequirement` preconditions; transactions intersect them with operation restrictions and read the current session epoch/identity/role/status/revision. No Firestore SDK object escapes. Domain reads are backend records; Server must project role-safe HTTP fields and recheck delayed responses. Membership is bounded to200 and conservatively measured against700,000 bytes including field overhead before writes. Default/max paging is10/100 domains and20/100 members/invitations; cursors bind the actor and resource context.

Invitations store digests, never secrets. Server generates32 random bytes and supplies their SHA-256 hex digest. Inspection accepts `{invitationId,tokenHash}` plus a current actor requirement. Returned management records exclude hashes. Archive increments the domain invitation epoch; restore cannot revive old links or replaced keys. Packet admission still requires Server's active-domain/current-key gate; the library does not promise a global archive cutoff or replay rejected traffic.

## Privileged operator composition

`require('@dronelink/persistence/operator').openAccessOperatorStore({projectId,databaseId,...})` opens a separate operator connection. Its declarations define preview/begin/user/domain migration, revisioned grant/recovery/repair/check/activation and close. IAM remains the security boundary; do not compose this entry point into public handlers. Server's separately installed CLI orchestrates it without SDK imports.

Migration inventories are bounded to200 domains/500 users; larger inventories fail explicitly. Private previews contain source digests and identity/mapping information, excluding machine keys, invitation tokens and sessions. Begin records the reviewed manifest in maintenance; user and domain operations commit progress independently. Reruns skip committed markers, retaining later role edits. A changed remaining source requires a fresh reviewed preview and explicit `reviseMigration` under the current control revision. Missing Owners remain blockers until a reviewed repair. Legacy flags never grant roles or verification. Recovery records a reason/audit and advances the session epoch without transferring memberships.

Managed checks inspect actual declared composite indexes; emulator results report `managedVerified:false`. Applying indexes and demonstrating managed readiness remain coordinated rollout work. Activation checks readiness and the expected control revision; it is never part of ordinary startup.

## Checks and releases

```sh
npm ci
npm run test:firestore:prepare
npm test
npm run test:storage
```

Preparation explicitly downloads emulator1.22.0 with its pinned SHA-256; `-- --from /absolute/cached.jar` uses matching cached bytes. Tests own loopback emulators and generated demo projects; no live target override is accepted. Public-interface tests use independent connections for roles, invitations, last-Owner races, lifecycle, migration/recovery and packet/session regressions. Managed Google/browser/deployment/hardware evidence is separate.

Commit source/tests/docs before `npm run pack:release`; then run `npm run check:release` and installed-archive replay. Packaging verifies Git provenance, exact members and hashes and refuses to overwrite release identities. Explicit consumer pinning never copies sibling source during normal builds.0.3.0 requires the matched M1 rollout; after activation, recover through maintenance and a compatible release, never the old membership-only backend.

## Preserved packet/session contract

Sessions retain fixed expiry and logout tombstones. Packet chunks acknowledge bounded volatile admission, not persistence; failed bounded writes drop without a durable retry queue. History/live APIs retain scoped cursors, individual packet IDs, owned listeners and bounded cancellation/close. No packet purge, TTL, reset or new telemetry adapter is introduced. Old MongoDB sources/fixtures/archives remain historical references, excluded from this runtime.

## 0.3.1 operator correction

The managed Firestore Admin API rejects an explicit nonzero page size for wildcard collection-group index listing (only0 is supported).0.3.1 omits that optional field, retaining bounded response/continuation validation. A read-only managed regression exercises the public operator readiness operation, which emulator-only checks could not validate. The separately installed Server operator adopts0.3.1; the deployed0.3.0 runtime contract/schema is unchanged and requires no policy rollback. Prior immutable archives are retained.

Run the explicit managed gate only against the reviewed staging plan, with DRONELINK_MANAGED_PROJECT=dronelink-25dbc, DRONELINK_MANAGED_DATABASE=(default), and DRONELINK_MANAGED_PLAN selecting its private file, then npm run test:managed:access. It reads schema/index/mapping readiness and never migrates/grants/activates.

## M1-B identity and relay storage (0.4.0)

Adds atomic authenticated `telemetry.admit`, publication-node/singleton Drone identity reads, and separately revocable gateway relay credentials. Node records use domain-local addresses; rediscovery retains membership and does not refresh observation state. Server owns strict wire validation and publication eligibility. Identity commits before best-effort packet-buffer admission; history may still be lost. Optional history origin/source fields retain forwarder attribution. See the [storage contract](../../docs/contracts/storage.md#m1-slice-b-storage-contract--2026-11-06) for methods, authentication/transaction boundaries and limits. No Iridium, grouping, shared-state/reset, history backfill or managed activation is included. Prior immutable releases remain unchanged.

## M1-C shared observations (0.5.0 source)

Enable this interface only in the matched C composition using `observationEpoch: 'm1-c-1'`. Missing observation records start empty; history is never a snapshot seed. The epoch remains stable across restarts/deployments. Server supplies eligible receipt IDs/context to `telemetry.admit`; its generation-bound ticket goes to `observations.enqueue`. Current reads/updates/reset/diagnostics are plain operations declared in `index.d.ts` and specified in the shared C storage/HTTP contracts.

Observations flush around one second with8MiB total volatile accounting. Value and NAME facets retain canonical bytes and separate receipt/change times; current snapshots remain until reset. Per-channel documents and full-channel update events are committed atomically with the Domain revision. Reset increments a node generation without changing identity, membership or history; older buffered tickets cannot recreate cleared state. Snapshot pages scan then catch up by revision/generation. Continuation is bounded to15minutes/1024 events/16MiB, independently of current snapshots. Reads use read-only transactions; update waits own and cancel their head listener.

A separate observation client uses1500ms non-retrying RPCs; batch work reserves time for its final RPC/transaction cleanup within a five-second budget. Shutdown has one shared five-second drain budget. Event sizes are measured and split;8MiB bounds include queued/in-flight work. Persistence failures drop the batch and increment a passive cumulative Domain counter. Diagnostic work caps1024 pending Domains/four concurrent transactions, with stable increment sequences; unsaved increments may be lost during crash, bounded shutdown or diagnostic saturation, which is logged. No transient-warning system or durable retry backlog exists. Existing session/access client behavior remains unchanged. Schema/payload maps are excluded from unnecessary indexing; no new cloud TTL policy is introduced.

Local checks: `npm test` passes type checks,33 native Firestore cases (including7 observation integration cases) and the release regression. The observation cases include independent stores, reset/old-buffer fencing, receipt order/coalesced change time, concurrent paged catch-up, roles/archive/revocation, exact FLOAT/name bytes, a real TCP storage outage/recovery and large channels. This is C.1 local source evidence, not immutable publication, Server/Client adoption or managed activation.


## M2-A-S1 writer compatibility and command fences (historical 0.6.0)

The runtime can opt into the prepared M2 writer contract with `commandContract: 'm2-a-1'`. This accepts internal access schema2 only when its `writerContract` matches, while retaining schema1 compatibility. Missing/incorrect opt-in fails closed on schema2. This option never changes the stored schema, activates dispatch, creates a queue or performs migration. The existing M1 migration operator remains schema1-only; M2 activation/recovery tooling is added in0.7.0 below.

The internal command-state module joins observation metadata changes, node reset and Domain archive in their existing native transactions. It validates a bounded pending board (64/node,256/Domain), completes coherent reads before staging writes and preserves earlier expiry/terminal timestamps. Metadata type/size/writability transitions invalidate pending writes, including changes away and back in one buffered commit. Value-only updates do not touch the command board. Reset preserves queries; archive invalidates all remaining operations permanently. Invalid state aborts the whole mutation instead of silently applying an unfenced change.

Internal observation storage schema2 retains metadata epochs; public snapshots/updates remain schema1 with the unchanged observation epoch and omit internal metadata fields. Event time is sampled after coherent intent reads and cannot precede a pending command's trusted acceptance time. Existing received payload bytes, observation receipt/change times, identities, sessions and role policies remain intact.

A minimal read-only `commands.get(actor,{domainId,commandId})` returns canonical intent/outcome under current Domain authority, including Viewer/archived reads, with safe attribution and no fingerprint/private reservation material. This is also the native S1 acceptance seam. Those APIs were absent in0.6.0;0.7.0 supplies the S2 operations below. Synthetic pending fixtures in tests exercise the future storage layout without enabling production dispatch.

Run the public-interface native suite and type/release checks through the commands above. Immutable release/installed-artifact evidence and remaining scope live in the [M2 plan](../../docs/planning/m2-command-delivery.md). Server adoption is separate; publishing this library does not update the hosted runtime or its operator pin. Prior release archives remain unchanged.

## M2-A-S2 native commands (0.7.0)

The `commands` surface now provides `prepare`, current-user `lookupSubmission`, canonical `submit`, own-node `consume`, immutable-ID `cancel`, live `get/list` and revision-checked `getSettings/updateSettings`. See the [plain contract](../../docs/contracts/storage.md#m2-a-command-storage-draft--2026-11-10) and exported declarations. Submit returns `{created,command}`; cancellation returns `{command,cancellationApplied}`. Consume takes `(machine,{domainId,nodeAddress,limit,attemptId})`. Only current shared Domain keys can consume; gateway credentials remain telemetry-only. The trusted Server must generate a fresh32-byte/base64url attempt ID per scheduled poll, retaining it across that job's native retries. Final packet construction stays in Server.

Unused reservations last300 seconds and accepted retry identity lasts604800 seconds. New acceptance validates current metadata, snapshots the60–86400-second Domain lifetime (default3600), assigns monotonic FIFO/priority and coalesces only its operation slot. Net-new capacity is64/node and256/Domain; net-zero replacement remains possible. Writes are priority3, queries0. A consumed response can be lost; a repeated internal attempt returns no packets and cannot take another batch. There is no lease, execution ACK or automatic write replay. History merges effective expiry with persisted outcomes and hides terminal records after seven days regardless of cleanup. Current permissions apply on each page; Viewer and archived reads are supported.

`commandClock?:()=>Date` is a trusted process-composition clock, sampled inside each transaction attempt. Never take it from HTTP input. Queue RPCs use a separate native client with five-second RPC deadlines, transport retries disabled and at most three transaction attempts; existing session/authority policies remain unchanged. All owned clients close with the store. Cleanup is explicit and bounded; no background command worker starts on import/open.

The separate `./operator` entry exports `openCommandOperatorStore` requiring explicit database and matching command contract. `preview` returns a secret-free inventory digest; reviewed `prepare` raises the global writer fence while commands remain disabled. `prepareDomain` initializes bounded state and additive HTTP Drone transport; `activate` verifies all Domain controls and managed composite indexes before enabling commands. Newly created schema2 Domains initialize their controls atomically. These are privileged operations, never browser routes. Fleet writer compatibility and managed TTL/index preparation must be established separately before activation; the database cannot prove that old processes/jobs have drained.

`disable` preserves pending data. Deliberate pre-M2 recovery is `disable` → drain jobs externally → `beginRecovery` → `recoverDomain` for **every** Domain → `finishRecovery`. Each Domain retires pending commands with `writer-downgrade` and lowers its internal observation header; the final coherent all-Domain proof requires empty boards/disabled controls/schema1 observation headers before lowering the global fence. Roles, sessions, identities, observations and retained history remain. Compatible recovery-time observation commits retain schema1 headers. `cleanup({domainId})` deletes at most64 elapsed reservation/attempt/terminal records; declared TTL/index changes require separate managed application. Never call activation/recovery automatically at runtime startup.

This independent library release does not change Server/Client/firmware pins, expose HTTP command routes, enable managed dispatch or establish hardware acceptance. S3 owns hosted integration.
