# @dronelink/protocol

Portable DroneLink constants, TypeScript declarations and independent packet fixtures. Version 0.1.1 is distributed as a pinned local npm archive; no registry publication is required. There are no runtime dependencies. This package defines no new wire version and contains no codec replacement.

Firmware is authoritative. `firmware/provenance.json` identifies the upstream commit, exact frozen bytes/checksums and the approved query-comment amendment that was uncommitted when captured. Headers and the relevant message implementation are included for reproducible host verification. Generated C++ definitions are comparison-only; firmware does not adopt this package.

```sh
npm run build
npm test
npm run test:firmware
npm run pack:release
```

Generation reads only frozen package inputs and writes only this package. `python3 tools/build.py --check --firmware /path/to/DroneNode` explicitly compares the live checkout read-only. `python3 tools/check_firmware.py --firmware /path/to/DroneNode` compiles the live matching firmware message source with platform/I/O stubs on the host. Neither command runs PlatformIO or its sibling-writing post-build hook.

Supported compatibility subset: valid non-query unframed packets, 1–16 payload bytes, uint8/uint32/float scalars and arrays, single ADDR values and single-byte CHAR/NAME strings with existing NUL trimming. Fixtures specify expected bytes independently of production codecs. `@dronelink/protocol/testing` is an optional Node-only conformance harness; it is separate from the browser-safe package entrypoint.

Query payloads include at least one ignored byte; query runtime corrections and capture-based verification are deferred. Multi-address helpers, Unicode semantics, strict malformed-input rejection, framing/CRC, transport and hardware parity are not established. The actual firmware message class is exercised on the host, not on ESP32.

Consume the exact archive through a local `file:vendor/dronelink-protocol-0.1.1.tgz` dependency and its lockfile. Keep previous archives with the matching consumer source/lockfiles for rollback. Never replace an existing version with different bytes. A release check rebuilds and compares the archive; changes require a new package version and reviewed provenance. Release generation never copies into sibling repositories.
