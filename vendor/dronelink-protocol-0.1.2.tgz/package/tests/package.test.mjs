import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import * as protocol from '../dist/index.mjs';

test('released package identifies exact firmware snapshot bytes', () => {
  const provenance = JSON.parse(readFileSync(new URL('../firmware/provenance.json', import.meta.url)));
  assert.match(provenance.baseRevision, /^[a-f0-9]{40}$/);
  for (const { snapshot, sha256 } of Object.values(provenance.files)) {
    const bytes = readFileSync(new URL('../' + snapshot, import.meta.url));
    assert.equal(createHash('sha256').update(bytes).digest('hex'), sha256);
  }
});

test('independent fixtures are structurally valid, typed and within the supported subset', () => {
  const { vectors } = JSON.parse(readFileSync(new URL('../fixtures.json', import.meta.url)));
  assert.equal(new Set(vectors.map(v => v.name)).size, vectors.length);
  for (const v of vectors) {
    const raw = Buffer.from(v.hex.replaceAll(' ', ''), 'hex');
    assert.deepEqual(raw, Buffer.from(v.base64, 'base64'), v.name);
    const d = v.decoded;
    assert.deepEqual([...raw.subarray(0, 4)], [d.source, d.node, d.channel, (d.priority << 6) | d.param], v.name);
    assert.equal(raw[4], (d.writable ? 128 : 0) | (d.msgType << 4) | (d.payload.length - 1), v.name);
    assert.ok(d.msgType >= 0 && d.msgType <= 5, v.name);
    assert.ok(d.payload.length >= 1 && d.payload.length <= 16, v.name);
    assert.equal(d.payload.length % protocol.DRONE_LINK_MSG_TYPE_SIZES[d.msgType], 0, v.name);
    assert.deepEqual([...raw.subarray(5)], d.payload, v.name);
    let values;
    if (d.msgType === 0) values = [...d.payload];
    if (d.msgType === 1) {
      assert.equal(d.payload.length, 4, 'only single-address fixtures are supported');
      const [source,node,channel,packed] = d.payload;
      values = [{source,node,channel,param:packed & 63,priority:packed >> 6}];
    }
    if (d.msgType === 2 || d.msgType === 3) {
      values = Array.from({length:d.payload.length/4}, (_,i) =>
        d.msgType === 2 ? raw.readUInt32LE(5+i*4) : raw.readFloatLE(5+i*4));
    }
    if (d.msgType === 4 || d.msgType === 5) values = [Buffer.from(d.payload).toString('latin1').split('\0')[0]];
    assert.deepEqual(values, d.values, v.name);
  }
});
