import test from 'node:test';
import assert from 'node:assert/strict';
import {readLinkPacket, ProtocolValidationError} from '../dist/index.mjs';
const good=Uint8Array.of(0,7,4,0x88,0x80,42);
test('raw decode rejects truncation and snapshots a visible byte window',()=>{
 assert.throws(()=>readLinkPacket(good.subarray(0,5)),ProtocolValidationError);
 const backing=Uint8Array.of(99,...good,88);const decoded=readLinkPacket(backing.subarray(1,7));
 assert.equal(decoded.priority,2);assert.equal(decoded.writable,true);assert.deepEqual([...decoded.payload],[42]);
 backing[6]=1;assert.deepEqual([...decoded.payload],[42]);
});

test('outgoing field/payload validation rejects coercion and keeps existing wire bytes',async()=>{
 const {encodeLinkPacket,typedPayload,textPayload,readLinkLog,encodeLinkLog}=await import('../dist/index.mjs');
 const fields=readLinkPacket(good);
 assert.deepEqual(encodeLinkPacket(fields,fields.payload),good);
 assert.throws(()=>typedPayload(0,[256]),ProtocolValidationError);
 assert.deepEqual([...textPayload('')],[0]);
 const log=encodeLinkLog(fields,fields.payload,0xfedcba98);
 assert.equal(readLinkLog(log).timestamp,0xfedcba98);
});

test('all type/length combinations use exact boundaries; bytes and float bit patterns survive', async()=>{
 const {encodeLinkPacket,readLinkLog,encodeLinkLog,byteView}=await import('../dist/index.mjs');
 for(let type=0;type<8;type++)for(let length=1;length<=16;length++) {
  const raw=Uint8Array.from([255,255,255,255,128|(type<<4)|(length-1),...Array.from({length},(_,i)=>i+1)]);
  if([1,2,3].includes(type)&&length%4) {assert.throws(()=>readLinkPacket(raw),ProtocolValidationError);continue;}
  const decoded=readLinkPacket(raw);assert.deepEqual(encodeLinkPacket(decoded,decoded.payload),raw);
  assert.deepEqual(readLinkLog(encodeLinkLog(decoded,decoded.payload,Date.now())).payload,decoded.payload);
  for(const view of [raw.buffer,new DataView(raw.buffer),Buffer.from(raw),Array.from(raw)])assert.deepEqual(readLinkPacket(view),decoded);
 }
 for(const input of [null,undefined,false,'abc',{},[-1],[256],[1.5],Array(6),[NaN]])assert.throws(()=>byteView(input),ProtocolValidationError);
 for(const hex of ['0100c07f','0000807f','000080ff','00000080']) {
  const raw=Uint8Array.from([0,0,0,0,0x33,...Buffer.from(hex,'hex')]);const d=readLinkPacket(raw);assert.deepEqual(encodeLinkPacket(d,d.payload),raw);
 }
});

test('every typed setter/header rejection is noncoercing and timestamps stay low32', async()=>{
 const {typedPayload,textPayload,encodeLinkPacket,encodeLinkLog}=await import('../dist/index.mjs');const fields=readLinkPacket(good);
 for(const [field,bad] of Object.entries({source:[-1,256,'1',NaN],node:[256],channel:[1.5],param:[64],priority:[4],msgType:[8],msgLength:[0,17],writable:[0,1,'true']}))
  for(const value of bad)assert.throws(()=>encodeLinkPacket({...fields,[field]:value},fields.payload),ProtocolValidationError);
 for(const type of [0,1,2,3])for(const value of [[],Array(17).fill(0),null,['1']])assert.throws(()=>typedPayload(type,value),ProtocolValidationError);
 for(const value of [-1,1.5,NaN,Infinity,Number.MAX_SAFE_INTEGER+1])assert.throws(()=>encodeLinkLog(fields,fields.payload,value),ProtocolValidationError);
 assert.deepEqual([...typedPayload(3,[NaN,Infinity,-Infinity,-0])].length,16);
 assert.deepEqual([...textPayload('a\0ÿ')],[97,0,255]);assert.throws(()=>textPayload('😀'),ProtocolValidationError);
});
