# @dronelink/persistence

Backend-only native Firestore operations. Server owns HTTP, Google verification, policy and deployment. This library opens no resources at import. Node22+, explicit project/database and managed credentials are required; Java21/the pinned emulator are development-only.

## Access-control source and adoption

0.3.0 implements [M1 A.1](../../docs/planning/m1-contracts-and-telemetry.md#slice-a-implementation-plan--2026-11-06): verified stable identities, transactional domain/member/role/key/lifecycle operations and targeted seven-day invitations. It replaces the membership-only interface and must not be installed into an old hosted application. Server currently retains its immutable0.2.0 runtime pin; the separately installed operator tool adopts0.3.0 first. The coordinated Server/Client/schema transition remains A.2–A.4. Keep all prior immutable archives.

`openFirestoreStore({projectId,databaseId,...})` returns `users,access,domains,invitations,sessions,packets,close`. It exposes no migration, grant, recovery or permanent deletion method. Server supplies trusted `ActorRequirement` preconditions; transactions intersect them with operation restrictions and read the current session epoch/identity/role/status/revision. No Firestore SDK object escapes. Domain reads are backend records; Server must project role-safe HTTP fields and recheck delayed responses. Membership is bounded to200 and conservatively measured against700,000 bytes including field overhead before writes. Default/max paging is10/100 domains and20/100 members/invitations; cursors bind the actor and resource context.

Invitations store digests, never secrets. Server generates32 random bytes and supplies their SHA-256 hex digest. Inspection accepts `{invitationId,tokenHash}` plus a current actor requirement. Returned management records exclude hashes. Archive increments the domain invitation epoch; restore cannot revive old links or replaced keys. Packet admission still requires Server's active-domain/current-key gate; the library does not promise a global archive cutoff or replay rejected traffic.

## Privileged operator composition

`require('@dronelink/persistence/operator').openAccessOperatorStore({projectId,databaseId,...})` opens a separate operator connection. Its declarations define preview/begin/user/domain migration, revisioned grant/recovery/repair/check/activation and close. IAM remains the security boundary; do not compose this entry point into public handlers. Server's separately installed CLI orchestrates it without SDK imports.

Migration inventories are bounded to200 domains/500 users; larger inventories fail explicitly. Private previews contain source digests and identity/mapping information, excluding machine keys, invitation tokens and sessions. Begin records the reviewed manifest in maintenance; user and domain operations commit progress independently. Reruns skip committed markers, retaining later role edits. A changed remaining source requires a fresh reviewed preview and explicit `reviseMigration` under the current control revision. Missing Owners remain blockers until a reviewed repair. Legacy flags never grant roles or verification. Recovery records a reason/audit and advances the session epoch without transferring memberships.

Managed checks inspect actual declared composite indexes; emulator results report `managedVerified:false`. Applying indexes and demonstrating managed readiness remain coordinated rollout work. Activation checks readiness and the expected control revision; it is never part of ordinary startup.

## Checks and releases

```sh
npm ci
npm run test:firestore:prepare
npm test
npm run test:storage
```

Preparation explicitly downloads emulator1.22.0 with its pinned SHA-256; `-- --from /absolute/cached.jar` uses matching cached bytes. Tests own loopback emulators and generated demo projects; no live target override is accepted. Public-interface tests use independent connections for roles, invitations, last-Owner races, lifecycle, migration/recovery and packet/session regressions. Managed Google/browser/deployment/hardware evidence is separate.

Commit source/tests/docs before `npm run pack:release`; then run `npm run check:release` and installed-archive replay. Packaging verifies Git provenance, exact members and hashes and refuses to overwrite release identities. Explicit consumer pinning never copies sibling source during normal builds.0.3.0 requires the matched M1 rollout; after activation, recover through maintenance and a compatible release, never the old membership-only backend.

## Preserved packet/session contract

Sessions retain fixed expiry and logout tombstones. Packet chunks acknowledge bounded volatile admission, not persistence; failed bounded writes drop without a durable retry queue. History/live APIs retain scoped cursors, individual packet IDs, owned listeners and bounded cancellation/close. No packet purge, TTL, reset or new telemetry adapter is introduced. Old MongoDB sources/fixtures/archives remain historical references, excluded from this runtime.

## 0.3.1 operator correction

The managed Firestore Admin API rejects an explicit nonzero page size for wildcard collection-group index listing (only0 is supported).0.3.1 omits that optional field, retaining bounded response/continuation validation. A read-only managed regression exercises the public operator readiness operation, which emulator-only checks could not validate. The separately installed Server operator adopts0.3.1; the deployed0.3.0 runtime contract/schema is unchanged and requires no policy rollback. Prior immutable archives are retained.

Run the explicit managed gate only against the reviewed staging plan, with DRONELINK_MANAGED_PROJECT=dronelink-25dbc, DRONELINK_MANAGED_DATABASE=(default), and DRONELINK_MANAGED_PLAN selecting its private file, then npm run test:managed:access. It reads schema/index/mapping readiness and never migrates/grants/activates.
