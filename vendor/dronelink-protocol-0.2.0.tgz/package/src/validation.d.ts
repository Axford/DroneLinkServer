export type PacketBytes = ArrayBuffer | ArrayBufferView | readonly number[];
export class ProtocolValidationError extends RangeError { code: string; field?: string; offset?: number; constructor(code: string, field?: string, offset?: number); }
export interface LinkFields {source:number;node:number;channel:number;param:number;priority:number;msgType:number;msgLength:number;writable:boolean;}
export interface DecodedLink extends LinkFields {payload:Uint8Array;}
export declare function integerField(value:number,min:number,max:number,field:string):number;
export declare function byteView(input:PacketBytes):Uint8Array;
export declare function payloadLength(type:number,length:number):void;
export declare function readLinkPacket(input:PacketBytes):DecodedLink;
export declare function encodeLinkPacket(fields:LinkFields,payload:PacketBytes):Uint8Array;
export declare function typedPayload(type:number,values:readonly number[] | ArrayBufferView):Uint8Array;
export declare function textPayload(text:string):Uint8Array;
export declare function readLinkLog(input:PacketBytes):DecodedLink & {timestamp:number};
export declare function encodeLinkLog(fields:LinkFields,payload:PacketBytes,timestamp:number):Uint8Array;
